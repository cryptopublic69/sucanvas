# MiniMax H3 分镜提示词格式

## 目录

- 路由
- Full-Reference 六段结构
- 素材与主体标签
- 镜头描述
- 声音

## 路由

本 Skill 主要处理带候选参考素材的逐分镜任务。选中非关键帧图片、视频或音频时，使用 Full-Reference 六段结构。

如果当前分镜经过筛选后完全不需要参考素材，应明确告诉用户该镜头应走文生视频任务，不要伪造空参考。

## Full-Reference 六段结构

严格按以下顺序输出纯英文执行提示词：

1. `subject_definitions:`
2. `summary:`
3. `retention_analysis:`
4. `detailed_description:`
5. `overall_soundscape:`
6. `non_diegetic_music:`

`subject_definitions` 定义本镜头持续可见或发声的 `<Subject N>`，并绑定 `<Picture N>`、`<Video N>` 或 `<Audio N>`。

`summary` 说明生成任务和镜头核心事件。

`retention_analysis` 分素材写明保留或参考的维度，避免互相污染。

`detailed_description` 写实际镜头、动作、构图、光线、时间轴和对白。

`overall_soundscape` 写环境声、同步音效和非语言人声。

`non_diegetic_music` 写配乐；无配乐时使用 `N/A`。

## 素材与主体标签

- 首次出现时使用完整尖括号标签：`<Picture 1>`、`<Video 1>`、`<Audio 1>`、`<Subject 1>`。
- 标签必须与当前分镜的内部素材选择完全一致。
- 不使用全局素材序号，不使用 `Picture 3` 表示本次提交列表中的第二张图。
- 每个选中素材只承担明确职责；不要让角色身份图同时无依据地控制场景、镜头和声音。
- 音色素材只参考音色和说话质感，不复制原音频台词、音素、停顿或背景声，除非用户明确要求复用原音频内容。

## 镜头描述

每个分镜作为独立 H3 任务编译。简单动作优先单镜头；需要切镜时使用 `[Shot 1]`，后续使用 `[Shot N] At 00:SS.mmm, ...`。

不要在英文提示词中写视频总时长。按本段情绪落点、画面信息量、动作因果和人物走位，从 2–15 秒中选择完整时长；15 秒为上限，不设 10 秒默认或推荐值。将结果写入统一提示词包的 `generationOptions.durationSeconds`，由生成节点作为任务参数读取。

镜头中只写可见或可听内容。保持人物身份、服装、关键道具、空间位置、动作因果和声音归属连续。

## 声音

对白紧跟发声主体与口型动作，并使用 `<d>[Language] exact dialogue</d>`。同一句对白只出现一次，不在声音总览重复原文。

没有背景音乐时写 `non_diegetic_music: N/A`。
