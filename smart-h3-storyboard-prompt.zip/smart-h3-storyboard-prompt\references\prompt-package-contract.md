# H3 统一提示词包契约

一个包对应一个分镜、一次素材筛选和一个提示词版本：

```json
{
  "schema": "infinite-canvas-h3-prompt-package/v1",
  "sceneKey": "S03",
  "title": "S3",
  "text": "subject_definitions: ...",
  "information": "中文说明...",
  "generationOptions": {
    "durationSeconds": 12
  },
  "referenceSelection": {
    "sceneKey": "S03",
    "assets": []
  }
}
```

- `text` 是完整英文 H3 执行提示词。
- `information` 是完整中文说明。
- `generationOptions.durationSeconds` 是该段生成任务的整数时长，必须为 2–15；由分镜实际需要决定，不设 10 秒默认或推荐值。
- `referenceSelection` 使用 `reference-selection-contract.md` 的结构，且必须与同包 `sceneKey` 一致。
- `generationOptions` 不属于 `text`、`information` 或 `referenceSelection`，三者不得重复记录时长。
- 只为实际使用参考素材的智能视频生成分镜创建此包；纯文生镜头不伪造空选择。
- 新建场景时，把包的 `sceneKey`、`title`、`text`、`information`、`referenceSelection` 原样放入 `scenes[]`。追加已有版本时，将包保存为 UTF-8 JSON，并通过 `send-to-infinite-canvas` 的 `-PromptPackagePath` 传入。
- 不把 `schema` 或 `referenceSelection` 塞入 `text` 或 `information`。画布保存时可忽略顶层 `schema`，但必须保留三个实际字段。
