---
name: smart-h3-storyboard-prompt
description: 独立把故事脚本或分镜与带素材备注的项目候选图片、音频、视频清单，编译为可一次写入 InfiniteCanvas 的逐分镜 MiniMax H3 提示词包；包内统一包含英文提示词、中文 Information 和内部素材选择。用于用户提到智能 H3 分镜提示词、H3 分镜联动、素材备注、自动判断每个镜头使用哪些素材、屏蔽未出现素材、从超过 9 张候选图片中为单次任务筛选最多 9 张、将全局素材 1/3 重编号为本次 Picture 1/2，或批量为多个分镜生成互不污染的 H3 任务时。
---

# 智能 H3 分镜提示词

独立完成“分镜理解 → 素材筛选 → 本次重编号 → H3 提示词 → 节点提交清单”。不要读取、调用或修改其他 H3、编剧或导演 Skill。

## 必读资源

- 每次使用先读 [references/reference-selection-contract.md](references/reference-selection-contract.md)。
- 生成 H3 提示词时再读 [references/h3-format.md](references/h3-format.md)。
- 需要交给 `send-to-infinite-canvas` 写入或追加版本时，按 [references/prompt-package-contract.md](references/prompt-package-contract.md) 生成统一提示词包。

## 输入契约

至少取得：

1. 一个或多个分镜文本；保留稳定 `sceneKey`，如 `S01`、`S02`。
2. 智能视频生成节点“复制清单”生成的候选素材 JSON。每项必须含稳定 `sourceId`、`kind`、全局顺序、标题；当前应用会同时带出素材节点持久保存的 `semanticDescription`（素材备注）。
3. 素材语义登记：优先使用清单中 `semanticDescription`。仅当该字段为空、互相冲突或不足以区分素材职责时，才请用户补充。
4. 要写入 InfiniteCanvas 时，取得精确的上游分镜 Content Iteration 节点 ID；不得从标题、位置或最近对话推测。没有该 ID 时，停止在生成提示词包，不得写入。

每次都以用户刚复制的候选清单为准；不得用较早对话中“图一/图二”的记忆覆盖当前 `sourceId`、顺序或 `semanticDescription`。标题和文件名都不是可靠语义，不得据此臆测人物身份。候选素材数量不受单次模型上限约束。

## H3 段落时长

- 为每个 H3 段落按情绪落点、画面信息量、动作因果和人物走位，直接选择一个完整时长，范围为 2–15 秒；15 秒是硬上限。
- 不设 10 秒默认或自动回退值。不要为了迎合预设秒数切断镜头，也不要无理由拉长简单画面。
- 每个统一提示词包都必须携带独立的 `generationOptions.durationSeconds` 整数。该值是生成节点可见的初始推荐时长，不是叙事文本；用户可在 Canvas 的生成提示词节点中手动覆盖它。
- 不得在英文 H3 提示词、中文 Information 或 `referenceSelection` 中写入时长。中文 Information 仍只解释英文提示词。

## 编译流程

### 1. 建立项目素材登记表

用稳定 `sourceId` 绑定素材语义。`semanticDescription` 是素材节点的持久备注，非空时为本次语义登记的权威来源；全局顺序只用于管理和稳定排序，不直接成为 H3 标签。

同一人物可登记多份不同职责的素材；必须区分身份、服装、场景、动作、音色等用途。

### 2. 逐分镜识别实际出现项

读取分镜中的人物、地点、关键道具、指定动作、声音和风格。只选择生成该分镜确实需要的素材。

- 未出现且未承担必要视觉或声音职责的素材必须排除。
- 不因素材已接入候选库而选择它。
- 不为“可能有帮助”加入无关素材，避免推理变慢和参考污染。
- 存在同名角色、隐含代词或场景歧义时先询问，不静默猜测。

### 3. 按本次任务重新连续编号

筛选后分别按图片、视频、音频的选中顺序从 1 连续编号：

- 图片：`<Picture 1>`、`<Picture 2>`……
- 视频：`<Video 1>`、`<Video 2>`……
- 音频：`<Audio 1>`、`<Audio 2>`……
- 可见持续主体：`<Subject 1>`、`<Subject 2>`……

全局素材 1、3 被选中时，它们在本次任务中必须成为 `<Picture 1>`、`<Picture 2>`；全局素材 2 不上传、不占位，也不得在提示词中留下 `<Picture 3>` 或空槽。

`<Subject N>` 是本次提示词的主体编号，与全局素材序号无关。一个场景或风格图片可以有 `<Picture N>` 而没有 `<Subject N>`。

### 4. 应用单次提交上限

候选库可以超过上限；只校验当前分镜选中的素材：

- 图片最多 9 张。
- 音频最多 2 个。
- 视频最多 1 个；是否可执行还取决于特殊节点当前工作流适配器是否提供视频输入。

超限时不得截断、不得自动丢弃末尾素材；列出超限项并要求用户删减或拆分分镜。

### 5. 生成 H3 提示词

提示词必须只引用本次内部素材选择中存在的连续标签。素材职责、`subject_definitions`、`retention_analysis` 和镜头描述必须使用同一套本次编号。

不得为了配合全局编号保留断号，不得在生成后单独修改素材选择而不重编提示词。

### 6. 组装统一提示词包

为每个分镜生成一个统一提示词包，严格使用 `prompt-package-contract.md` 的字段。包内的 `text`、`information`、`referenceSelection` 和 `generationOptions.durationSeconds` 必须来自同一次编译、同一分镜，禁止分别交付、混用或让后续流程重新猜测素材。

`information` 仍只写给用户查看的中文说明；`referenceSelection` 只作为同一提示词包内的机器字段；`generationOptions.durationSeconds` 是生成提示词版本的可见初始推荐时长。Canvas 如保存用户手动覆盖值，应以覆盖值执行，但不得改写英文提示词、中文 Information 或 `referenceSelection`。三者都不得拼进英文提示词或彼此混用。

将包整体交给 `send-to-infinite-canvas`：新建分镜可直接作为 `scenes[]` 条目；追加版本使用 `-PromptPackagePath`。特殊视频节点只按包内 `referenceSelection` 中的 `sourceId` 筛选真实上传参数；未列出的候选素材不得进入 `imagePaths`、`audioPaths` 或 `videoPaths`。

## 写入后的上游分镜关联（硬性要求）

智能 H3 提示词包从分镜编译而来时，写入不能止于 `CreateMissingScenes`。这是强制两步流程：

1. 使用 `CreateMissingScenes` 创建或确认场景绑定；只以 `promptSetId + sceneKey` 识别目标场景。
2. 立即查询当前 Canvas 内容图，对本次新建的每个提示词节点调用 `CreateContentEdges`，建立 `上游分镜节点 -> 该提示词节点` 的一条 `content-derivation` 边。

边的源必须是输入中提供的精确上游分镜节点 ID，目标必须是本次场景绑定返回的精确节点 ID。提示词节点已经由场景批量布置，因此创建边时不得设置 `layoutPlacement: "right-of-source"`，避免改动现有位置。完成后重新查询内容图，要求每个新建场景恰有一条来自该上游分镜的持久 `content-derivation` 边；少一条、指向错误上游或关联不明时，写入视为不完整。已有场景的追加版本不重复创建同一条边。

当用户选中已有智能 H3 提示词节点并要求定向更新时，先通过 `GetCanvasSelection` 获取精确节点 ID，再以 `promptSetId + sceneKey` 确认其场景绑定。追加前必须查询该节点的 `content-derivation` 入边，读取每个上游分镜节点当前激活的版本 ID 与标签；将提示词包通过 `AppendVersion -PromptPackagePath` 追加时，要求新版本自动继承这些上游版本为 `derivedFrom`。写入响应必须逐项返回相同的上游节点和版本；缺失时视为写入失败，不得称新版本可用，也不得以手工切换、可见标题或旧版本来源替代当前上游版本。

## 交付

每个分镜只交付一个不可拆分的统一提示词包。不要再把内部素材选择 JSON 和英文提示词作为两份独立结果交付。

仅在用户要求人工核对时，在包外展示简短映射摘要，例如：

```text
S03：全局图 1 → Picture 1 / Subject 1
     全局图 3 → Picture 2 / Subject 2
     全局图 2 → 跳过，不上传
```

不要把内部素材选择 JSON 或映射摘要写进英文 H3 提示词或中文 Information。

## 硬性自检

交付前逐分镜确认：

- 所有选中项都确实出现在分镜或承担明确必要职责。
- 所有未选项都不会进入提交参数。
- 各媒体标签从 1 连续且无断号、重复或越界。
- 英文提示词中的每个 Picture、Video、Audio 标签都存在于内部素材选择。
- 内部素材选择中的每个素材都在英文提示词中承担明确职责。
- `sourceId` 来自候选素材清单且没有拼写、类型或重复错误。
- 当前分镜没有超过 9 图、2 音频、1 视频。
- `generationOptions.durationSeconds` 为 2–15 的整数，且以本段动作、画面和情绪需要为依据，不来自默认值。
- 英文提示词、中文 Information 和 `referenceSelection` 均不包含时长。
- 多分镜批量交付时，每个分镜独立筛选和编号，不复用上一分镜的临时编号。
- 写入 Canvas 时已提供精确上游分镜节点 ID，并且每个本次新建的 H3 提示词节点都与该分镜保有一条已验证的 `content-derivation` 线条关联。
