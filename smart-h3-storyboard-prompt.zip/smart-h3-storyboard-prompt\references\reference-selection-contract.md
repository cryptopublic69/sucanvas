# 分镜素材选择内部契约

## 候选素材清单

特殊视频节点的“复制清单”提供稳定 `sourceId`、媒体类型、全局顺序、标题和素材节点持久保存的 `semanticDescription`（素材备注）；需要传给 Skill 时复制其中的 JSON：

```json
{
  "schema": "infinite-canvas-h3-candidate-catalog/v1",
  "generatorId": "node:generator-id",
  "assets": [
    {
      "sourceId": "node:image-a",
      "kind": "image",
      "globalOrder": 1,
      "title": "角色阿青正面",
      "semanticDescription": "女 1 号样貌"
    }
  ]
}
```

非空 `semanticDescription` 是本次素材语义的权威来源，直接复用，不要求用户重复说明。每次以刚复制的清单为准，不得用较早对话中的“图一/图二”映射覆盖它。标题不是稳定 ID，也不是可靠语义。

## 提示词版本字段

每个提示词版本保持三个独立字段：

- `text`：英文 H3 提示词。
- `information`：只供用户查看的中文说明；不得加入机器数据。
- `referenceSelection`：程序内部素材选择，只用于特殊视频节点筛选真实提交参数。

`referenceSelection` 结构：

```json
{
  "sceneKey": "S03",
  "assets": [
    {
      "sourceId": "node:image-a",
      "kind": "image",
      "label": "Picture 1",
      "subjectLabel": "Subject 1",
      "role": "character identity and appearance"
    },
    {
      "sourceId": "node:audio-b",
      "kind": "audio",
      "label": "Audio 1",
      "subjectLabel": "Subject 1",
      "role": "voice timbre only"
    }
  ]
}
```

除非用户明确要求检查内部数据，不要把 `referenceSelection` JSON 显示给用户。

## 写入 InfiniteCanvas

创建场景时在每个 `scenes[]` 项中同时提交 `text`、`information`、`referenceSelection`。

追加版本时在版本请求中同时提交 `text`、`information`、`referenceSelection`。三项必须属于同一个分镜和同一次编译结果，不可拆开复用。

## 校验

- `sourceId` 必须来自当前候选清单。
- `kind` 必须与实际节点类型一致。
- 同一 `sourceId` 不重复。
- Picture、Video、Audio 标签按各自选中顺序从 1 连续编号。
- Subject 标签按首次出现顺序从 1 连续编号。
- 英文提示词的素材标签与 `referenceSelection` 一致。
- 单个分镜最多 9 图、2 音频、1 视频。
- 错误时禁止回退为上传全部候选素材。
