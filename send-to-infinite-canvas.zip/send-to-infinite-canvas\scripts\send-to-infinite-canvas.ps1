[CmdletBinding(DefaultParameterSetName = 'Text')]
param(
    [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline = $true, ParameterSetName = 'Text')]
    [AllowEmptyString()]
    [string]$Text,

    [Parameter(Mandatory = $true, ParameterSetName = 'Path')]
    [ValidateNotNullOrEmpty()]
    [string]$Path,

    [string]$Title = 'From Codex',
    [string]$Source = 'codex',
    [string]$RequestId,
    [ValidatePattern('^[a-z0-9][a-z0-9-]*$')]
    [string]$Kind = 'text'
)

begin {
    function ConvertTo-JsonString {
        param([AllowEmptyString()][string]$Value)

        $builder = [System.Text.StringBuilder]::new($Value.Length + 16)
        foreach ($character in $Value.ToCharArray()) {
            $code = [int]$character
            if ($code -eq 8) {
                [void]$builder.Append('\b')
            }
            elseif ($code -eq 9) {
                [void]$builder.Append('\t')
            }
            elseif ($code -eq 10) {
                [void]$builder.Append('\n')
            }
            elseif ($code -eq 12) {
                [void]$builder.Append('\f')
            }
            elseif ($code -eq 13) {
                [void]$builder.Append('\r')
            }
            elseif ($code -eq 34) {
                [void]$builder.Append('\"')
            }
            elseif ($code -eq 92) {
                [void]$builder.Append('\\')
            }
            elseif ($code -lt 32) {
                [void]$builder.AppendFormat('\u{0:x4}', $code)
            }
            else {
                [void]$builder.Append($character)
            }
        }
        $builder.ToString()
    }

    $pipelineText = [System.Collections.Generic.List[string]]::new()
}

process {
    if ($PSCmdlet.ParameterSetName -eq 'Text') {
        $pipelineText.Add($Text)
    }
}

end {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8

    if ($PSCmdlet.ParameterSetName -eq 'Path') {
        $resolvedPath = (Resolve-Path -LiteralPath $Path -ErrorAction Stop).Path
        $finalText = Get-Content -LiteralPath $resolvedPath -Raw -Encoding UTF8
    }
    else {
        $finalText = [string]::Join("`n", $pipelineText)
    }

    $localAppData = [Environment]::GetFolderPath('LocalApplicationData')
    $configPath = Join-Path $localAppData 'InfiniteCanvas\api.json'
    if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
        throw "InfiniteCanvas API config was not found. Start InfiniteCanvas, then retry. Expected: $configPath"
    }

    $config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]::IsNullOrWhiteSpace([string]$config.baseUrl) -or [string]::IsNullOrWhiteSpace([string]$config.token)) {
        throw 'InfiniteCanvas API config is invalid. Restart InfiniteCanvas, then retry.'
    }

    $json = '{"kind":"' + (ConvertTo-JsonString $Kind) +
        '","title":"' + (ConvertTo-JsonString $Title) +
        '","content":{"text":"' + (ConvertTo-JsonString $finalText) +
        '"},"source":"' + (ConvertTo-JsonString $Source) + '"'
    if (-not [string]::IsNullOrWhiteSpace($RequestId)) {
        $json += ',"requestId":"' + (ConvertTo-JsonString $RequestId) + '"'
    }
    $json += '}'
    $headers = @{ Authorization = "Bearer $($config.token)" }

    try {
        $response = Invoke-RestMethod `
            -Method Post `
            -Uri "$($config.baseUrl)/v1/nodes" `
            -Headers $headers `
            -ContentType 'application/json; charset=utf-8' `
            -Body $json `
            -TimeoutSec 10
    }
    catch {
        throw "Could not send text to InfiniteCanvas. Make sure the app is running, then retry. $($_.Exception.Message)"
    }

    Write-Output "nodeId=$($response.node.id)"
    Write-Output "created=$($response.created)"
}
