[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('ListPromptSets', 'GetSceneBindings', 'GetCanvasSelection', 'ListContentGraph', 'CreateContentNodes', 'DeleteContentNodes', 'CloneContentNodes', 'PlaceContentNodes', 'CreateContentEdges', 'DeleteContentEdges', 'AppendContentVersion', 'DeleteContentVersion', 'CreateMissingScenes', 'AppendVersion')]
    [string]$Action,

    [switch]$ActiveCanvas,
    [string]$CanvasId,
    [string]$PromptSetId,
    [string]$SceneKey,
    [string]$NodeId,
    [string]$VersionId,
    [string]$ManifestPath,
    [AllowEmptyString()]
    [string]$Text,
    [string]$Path,
    [AllowEmptyString()]
    [string]$Information,
    [string]$InformationPath,
    [string]$PromptPackagePath,
    [string]$Title,
    [string]$TitlePath,
    [string]$Source = 'codex',
    [string]$RequestId,
    [int]$ExpectedVersionCount = -1,
    [string]$ApiConfigPath
)

function ConvertTo-JsonString {
    param([AllowEmptyString()][string]$Value)

    $builder = [System.Text.StringBuilder]::new($Value.Length + 16)
    foreach ($character in $Value.ToCharArray()) {
        $code = [int]$character
        if ($code -eq 8) { [void]$builder.Append('\b') }
        elseif ($code -eq 9) { [void]$builder.Append('\t') }
        elseif ($code -eq 10) { [void]$builder.Append('\n') }
        elseif ($code -eq 12) { [void]$builder.Append('\f') }
        elseif ($code -eq 13) { [void]$builder.Append('\r') }
        elseif ($code -eq 34) { [void]$builder.Append('\"') }
        elseif ($code -eq 92) { [void]$builder.Append('\\') }
        elseif ($code -lt 32) { [void]$builder.AppendFormat('\u{0:x4}', $code) }
        else { [void]$builder.Append($character) }
    }
    $builder.ToString()
}

function Read-Utf8Text {
    param(
        [string]$InlineValue,
        [string]$FilePath,
        [string]$Label,
        [switch]$Required
    )

    if (-not [string]::IsNullOrEmpty($InlineValue) -and -not [string]::IsNullOrEmpty($FilePath)) {
        throw "Use either the inline $Label value or its path, not both."
    }
    if (-not [string]::IsNullOrEmpty($FilePath)) {
        $resolvedPath = (Resolve-Path -LiteralPath $FilePath -ErrorAction Stop).Path
        return Get-Content -LiteralPath $resolvedPath -Raw -Encoding UTF8
    }
    if ($Required -and [string]::IsNullOrEmpty($InlineValue)) {
        throw "$Label is required."
    }
    return [string]$InlineValue
}

function Read-PromptPackage {
    param([string]$FilePath)

    $resolvedPath = (Resolve-Path -LiteralPath $FilePath -ErrorAction Stop).Path
    $raw = Get-Content -LiteralPath $resolvedPath -Raw -Encoding UTF8
    try {
        $package = $raw | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "PromptPackagePath must be valid UTF-8 JSON: $($_.Exception.Message)"
    }
    if ($null -eq $package -or $package -is [System.Array]) {
        throw 'PromptPackagePath must contain one prompt-package object.'
    }
    foreach ($field in @('text', 'information', 'referenceSelection', 'generationOptions')) {
        if ($null -eq $package.PSObject.Properties[$field]) {
            throw "PromptPackagePath must contain '$field'."
        }
    }
    if ($package.text -isnot [string] -or $package.information -isnot [string]) {
        throw 'PromptPackagePath text and information must be strings.'
    }
    if ($null -eq $package.referenceSelection -or $package.referenceSelection -is [string] -or $package.referenceSelection -is [System.Array]) {
        throw 'PromptPackagePath referenceSelection must be an object.'
    }
    Assert-PromptGenerationOptions -GenerationOptions $package.generationOptions -Label 'PromptPackagePath generationOptions'
    return $package
}

function Assert-PromptGenerationOptions {
    param($GenerationOptions, [string]$Label)

    if ($null -eq $GenerationOptions -or $GenerationOptions -is [string] -or $GenerationOptions -is [System.Array]) {
        throw "$Label must be an object."
    }
    if ($null -eq $GenerationOptions.PSObject.Properties['durationSeconds']) {
        throw "$Label must contain durationSeconds."
    }
    $durationSeconds = $GenerationOptions.durationSeconds
    if ($durationSeconds -isnot [byte] -and $durationSeconds -isnot [int] -and $durationSeconds -isnot [long] -and $durationSeconds -isnot [double] -and $durationSeconds -isnot [decimal]) {
        throw "$Label durationSeconds must be an integer from 2 to 15."
    }
    if ([double]$durationSeconds -ne [Math]::Floor([double]$durationSeconds) -or [double]$durationSeconds -lt 2 -or [double]$durationSeconds -gt 15) {
        throw "$Label durationSeconds must be an integer from 2 to 15."
    }
}

function Require-Value {
    param([string]$Value, [string]$Label)
    if ([string]::IsNullOrWhiteSpace($Value)) {
        throw "$Label is required for action $Action."
    }
}

function Assert-ExactText {
    param(
        [AllowNull()][object]$Actual,
        [AllowEmptyString()][string]$Expected,
        [string]$Label
    )

    $actualText = if ($null -eq $Actual) { $null } else { [string]$Actual }
    if ($null -eq $actualText -or -not [string]::Equals($actualText, $Expected, [System.StringComparison]::Ordinal)) {
        throw "UTF-8 round-trip verification failed for $Label. The response did not exactly match the submitted text. Do not retry with a new RequestId."
    }
}

function Invoke-Utf8JsonRequest {
    param(
        [ValidateSet('GET', 'POST', 'DELETE')]
        [string]$Method,
        [string]$Uri,
        [AllowNull()][string]$Body,
        [int]$TimeoutSec
    )

    $request = [System.Net.HttpWebRequest]::Create($Uri)
    $request.Method = $Method
    $request.Accept = 'application/json'
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = $TimeoutSec * 1000
    $request.Headers[[System.Net.HttpRequestHeader]::Authorization] = "Bearer $($config.token)"

    if ($Method -eq 'POST') {
        $request.ContentType = 'application/json; charset=utf-8'
        $requestBytes = $script:StrictUtf8.GetBytes([string]$Body)
        $request.ContentLength = $requestBytes.Length
        $requestStream = $request.GetRequestStream()
        try {
            $requestStream.Write($requestBytes, 0, $requestBytes.Length)
        }
        finally {
            $requestStream.Dispose()
        }
    }

    $webResponse = $null
    try {
        $webResponse = $request.GetResponse()
    }
    catch [System.Net.WebException] {
        $errorResponse = $_.Exception.Response
        if ($null -eq $errorResponse) {
            throw
        }
        try {
            $errorStream = $errorResponse.GetResponseStream()
            $errorMemory = [System.IO.MemoryStream]::new()
            try {
                $errorStream.CopyTo($errorMemory)
                $errorText = $script:StrictUtf8.GetString($errorMemory.ToArray())
            }
            finally {
                $errorMemory.Dispose()
                $errorStream.Dispose()
            }
            throw "HTTP $([int]$errorResponse.StatusCode): $errorText"
        }
        finally {
            $errorResponse.Dispose()
        }
    }

    try {
        $responseStream = $webResponse.GetResponseStream()
        $responseMemory = [System.IO.MemoryStream]::new()
        try {
            $responseStream.CopyTo($responseMemory)
            $responseText = $script:StrictUtf8.GetString($responseMemory.ToArray())
        }
        finally {
            $responseMemory.Dispose()
            $responseStream.Dispose()
        }
    }
    finally {
        $webResponse.Dispose()
    }

    if ([string]::IsNullOrWhiteSpace($responseText)) {
        return $null
    }
    return $responseText | ConvertFrom-Json
}

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$script:StrictUtf8 = [System.Text.UTF8Encoding]::new($false, $true)

$configPath = if ([string]::IsNullOrWhiteSpace($ApiConfigPath)) {
    $localAppData = [Environment]::GetFolderPath('LocalApplicationData')
    Join-Path $localAppData 'InfiniteCanvas\api.json'
}
else {
    $ApiConfigPath
}
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "InfiniteCanvas API config was not found. Start InfiniteCanvas, then retry. Expected: $configPath"
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace([string]$config.baseUrl) -or [string]::IsNullOrWhiteSpace([string]$config.token)) {
    throw 'InfiniteCanvas API config is invalid. Restart InfiniteCanvas, then retry.'
}
try {
    if ($Action -eq 'ListPromptSets') {
        $query = if ($ActiveCanvas) { '?activeCanvasOnly=true' } else { '' }
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/prompt-sets$query" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'GetSceneBindings') {
        Require-Value $PromptSetId 'PromptSetId'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'GetCanvasSelection') {
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/canvas-selection" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'ListContentGraph') {
        $query = if ([string]::IsNullOrWhiteSpace($CanvasId)) { '' } else { '?canvasId=' + [Uri]::EscapeDataString($CanvasId) }
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$query" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'CreateContentNodes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.requestId)) {
            throw 'The UTF-8 manifest must contain a stable requestId.'
        }
        $manifestNodes = @($manifest.nodes)
        if ($manifestNodes.Count -eq 0) {
            throw 'The UTF-8 manifest must contain at least one node.'
        }
        $allowedContentTypes = @('plot', 'script', 'storyboard', 'prompt')
        $source = if ([string]::IsNullOrWhiteSpace([string]$manifest.source)) { 'codex' } else { [string]$manifest.source }
        $createdAt = [DateTime]::UtcNow.ToString('o')
        $nodeInputs = @()
        for ($index = 0; $index -lt $manifestNodes.Count; $index += 1) {
            $manifestNode = $manifestNodes[$index]
            $contentType = if ([string]::IsNullOrWhiteSpace([string]$manifestNode.contentType)) {
                [string]$manifest.contentType
            }
            else {
                [string]$manifestNode.contentType
            }
            if ($allowedContentTypes -notcontains $contentType) {
                throw "Node $($index + 1) has invalid contentType '$contentType'. Use plot, script, storyboard, or prompt."
            }
            $title = [string]$manifestNode.title
            if ([string]::IsNullOrWhiteSpace($title)) {
                throw "Node $($index + 1) must contain an explicit title."
            }
            $textValue = if ($null -eq $manifestNode.PSObject.Properties['text']) { '' } else { [string]$manifestNode.text }
            $informationValue = if ($null -eq $manifestNode.PSObject.Properties['information']) { '' } else { [string]$manifestNode.information }
            if ([string]::IsNullOrEmpty($textValue) -and [string]::IsNullOrEmpty($informationValue)) {
                throw "Node $($index + 1) must contain text or information."
            }
            $versionId = 'version:' + [Guid]::NewGuid().ToString('D')
            $requestId = ([string]$manifest.requestId) + ':' + ($index + 1)
            $version = [ordered]@{
                id = $versionId
                label = 'v1'
                title = $title
                text = $textValue
                information = $informationValue
                createdAt = $createdAt
                requestId = $requestId
                source = $source
            }
            $nodeInputs += [ordered]@{
                canvasId = if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) { $null } else { [string]$manifest.canvasId }
                kind = 'text'
                title = $title
                content = [ordered]@{
                    text = $textValue
                    information = $informationValue
                    contentNode = $true
                    contentType = $contentType
                    promptVersions = @($version)
                    activePromptVersionId = $versionId
                    bestPromptVersionId = ''
                }
                source = $source
                requestId = $requestId
                width = 360
                height = 320
            }
        }
        $body = @{ nodes = $nodeInputs } | ConvertTo-Json -Depth 32
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/nodes:create-batch" `
            -Body $body `
            -TimeoutSec 30

        $mutations = @($response.nodes)
        if ($mutations.Count -ne $manifestNodes.Count) {
            throw "Completeness verification failed: expected $($manifestNodes.Count) nodes, but the response contained $($mutations.Count)."
        }
        for ($index = 0; $index -lt $mutations.Count; $index += 1) {
            $mutation = $mutations[$index]
            $expected = $manifestNodes[$index]
            $expectedType = if ([string]::IsNullOrWhiteSpace([string]$expected.contentType)) { [string]$manifest.contentType } else { [string]$expected.contentType }
            $expectedText = if ($null -eq $expected.PSObject.Properties['text']) { '' } else { [string]$expected.text }
            $expectedInformation = if ($null -eq $expected.PSObject.Properties['information']) { '' } else { [string]$expected.information }
            Assert-ExactText $mutation.node.title ([string]$expected.title) "node $($index + 1) title"
            Assert-ExactText $mutation.node.content.text $expectedText "node $($index + 1) text"
            Assert-ExactText $mutation.node.content.information $expectedInformation "node $($index + 1) Information"
            Assert-ExactText $mutation.node.content.contentType $expectedType "node $($index + 1) content type"
            if (-not [bool]$mutation.node.content.contentNode) {
                throw "Post-write verification failed: node $($index + 1) is not a content iteration node."
            }
            $activeVersionId = [string]$mutation.node.content.activePromptVersionId
            $activeVersion = @($mutation.node.content.promptVersions) | Where-Object { [string]$_.id -eq $activeVersionId } | Select-Object -First 1
            if ($null -eq $activeVersion -or [string]$activeVersion.label -ne 'v1') {
                throw "Post-write verification failed: node $($index + 1) has no active v1."
            }
            Assert-ExactText $activeVersion.text $expectedText "node $($index + 1) version text"
            Assert-ExactText $activeVersion.information $expectedInformation "node $($index + 1) version Information"
        }

        Start-Sleep -Milliseconds 300
        $graphQuery = if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) { '' } else { '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.canvasId) }
        $graph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        $persistedById = @{}
        foreach ($node in @($graph.nodes)) { $persistedById[[string]$node.id] = $node }
        $persistedCreated = @()
        for ($index = 0; $index -lt $mutations.Count; $index += 1) {
            $mutation = $mutations[$index]
            $nodeId = [string]$mutation.node.id
            if (-not $persistedById.ContainsKey($nodeId)) {
                throw "Post-write verification failed: active Canvas content graph omitted node '$nodeId'."
            }
            if ([bool]$mutation.created) { $persistedCreated += $persistedById[$nodeId] }
        }
        if ($persistedCreated.Count -gt 1) {
            $rowY = [double]$persistedCreated[0].y
            for ($index = 1; $index -lt $persistedCreated.Count; $index += 1) {
                $previous = $persistedCreated[$index - 1]
                $current = $persistedCreated[$index]
                if ([Math]::Abs(([double]$current.y) - $rowY) -gt 0.01) {
                    throw 'Post-write layout verification failed: created content nodes are not on one horizontal row.'
                }
                if ([double]$current.x -le ([double]$previous.x + [double]$previous.width)) {
                    throw 'Post-write layout verification failed: created content nodes are not ordered left-to-right without overlap.'
                }
            }
        }
    }
    elseif ($Action -eq 'DeleteContentNodes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) {
            throw 'The UTF-8 node manifest must contain canvasId.'
        }
        $manifestNodes = @($manifest.nodes)
        if ($manifestNodes.Count -eq 0) {
            throw 'The UTF-8 node manifest must contain at least one node.'
        }
        $graphQuery = '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.canvasId)
        $graph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        foreach ($expected in $manifestNodes) {
            if ([string]::IsNullOrWhiteSpace([string]$expected.id)) {
                throw 'Every deleted content node must contain id.'
            }
            $persisted = @($graph.nodes) | Where-Object { [string]$_.id -eq [string]$expected.id }
            if (@($persisted).Count -ne 1) {
                throw "Pre-delete verification failed: content node '$($expected.id)' is not in the supplied Canvas."
            }
            if (-not [bool]$persisted[0].content.contentNode) {
                throw "Pre-delete verification failed: node '$($expected.id)' is not a content node."
            }
        }
        $deleted = @()
        foreach ($expected in $manifestNodes) {
            $encodedNodeId = [Uri]::EscapeDataString([string]$expected.id)
            $mutation = Invoke-Utf8JsonRequest `
                -Method DELETE `
                -Uri "$($config.baseUrl)/v1/nodes/$encodedNodeId" `
                -TimeoutSec 10
            Assert-ExactText $mutation.id ([string]$expected.id) 'deleted node ID'
            $deleted += $mutation
        }
        $verifiedGraph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        foreach ($expected in $manifestNodes) {
            if (@($verifiedGraph.nodes | Where-Object { [string]$_.id -eq [string]$expected.id }).Count -ne 0) {
                throw "Post-delete verification failed: node '$($expected.id)' still exists."
            }
        }
        $response = [ordered]@{
            canvasId = [string]$manifest.canvasId
            deletedNodes = $deleted
            nodeCount = $deleted.Count
        }
    }
    elseif ($Action -eq 'CreateContentEdges') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) {
            throw 'The UTF-8 edge manifest must contain canvasId.'
        }
        $manifestEdges = @($manifest.edges)
        if ($manifestEdges.Count -eq 0) {
            throw 'The UTF-8 edge manifest must contain at least one edge.'
        }
        $mutations = @()
        foreach ($edge in $manifestEdges) {
            if ([string]::IsNullOrWhiteSpace([string]$edge.sourceNodeId) -or [string]::IsNullOrWhiteSpace([string]$edge.targetNodeId)) {
                throw 'Every content edge must contain sourceNodeId and targetNodeId.'
            }
            $kind = if ([string]::IsNullOrWhiteSpace([string]$edge.kind)) { 'content-derivation' } else { [string]$edge.kind }
            if ($kind -ne 'content-derivation') {
                throw "Unsupported content edge kind '$kind'."
            }
            $layoutPlacement = [string]$edge.layoutPlacement
            if (-not [string]::IsNullOrWhiteSpace($layoutPlacement) -and $layoutPlacement -ne 'right-of-source') {
                throw "Unsupported content edge layoutPlacement '$layoutPlacement'."
            }
            $metadata = [ordered]@{ relation = 'content-derivation' }
            if ($layoutPlacement -eq 'right-of-source') {
                $metadata.layoutPlacement = $layoutPlacement
                $metadata.captureInitialVersionSources = $true
            }
            $body = [ordered]@{
                canvasId = [string]$manifest.canvasId
                sourceNodeId = [string]$edge.sourceNodeId
                targetNodeId = [string]$edge.targetNodeId
                kind = $kind
                metadata = $metadata
            } | ConvertTo-Json -Depth 8
            $mutation = Invoke-Utf8JsonRequest `
                -Method POST `
                -Uri "$($config.baseUrl)/v1/edges" `
                -Body $body `
                -TimeoutSec 10
            Assert-ExactText $mutation.canvasId ([string]$manifest.canvasId) 'edge Canvas ID'
            Assert-ExactText $mutation.sourceNodeId ([string]$edge.sourceNodeId) 'edge source node ID'
            Assert-ExactText $mutation.targetNodeId ([string]$edge.targetNodeId) 'edge target node ID'
            Assert-ExactText $mutation.kind 'content-derivation' 'edge kind'
            $mutations += $mutation
        }
        $graphQuery = '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.canvasId)
        $graph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        foreach ($expected in $manifestEdges) {
            $persisted = @($graph.edges) | Where-Object {
                [string]$_.sourceNodeId -eq [string]$expected.sourceNodeId -and
                [string]$_.targetNodeId -eq [string]$expected.targetNodeId -and
                [string]$_.kind -eq 'content-derivation'
            }
            if (@($persisted).Count -ne 1) {
                throw "Post-write verification failed: expected exactly one persisted edge from '$($expected.sourceNodeId)' to '$($expected.targetNodeId)'."
            }
        }
        $response = [ordered]@{
            canvasId = [string]$manifest.canvasId
            edges = $mutations
            edgeCount = $mutations.Count
        }
    }
    elseif ($Action -eq 'DeleteContentEdges') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) {
            throw 'The UTF-8 edge manifest must contain canvasId.'
        }
        $manifestEdges = @($manifest.edges)
        if ($manifestEdges.Count -eq 0) {
            throw 'The UTF-8 edge manifest must contain at least one edge.'
        }
        $graphQuery = '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.canvasId)
        $graph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        foreach ($expected in $manifestEdges) {
            if ([string]::IsNullOrWhiteSpace([string]$expected.id) -or
                [string]::IsNullOrWhiteSpace([string]$expected.sourceNodeId) -or
                [string]::IsNullOrWhiteSpace([string]$expected.targetNodeId)) {
                throw 'Every deleted content edge must contain id, sourceNodeId, and targetNodeId.'
            }
            $persisted = @($graph.edges) | Where-Object {
                [string]$_.id -eq [string]$expected.id -and
                [string]$_.sourceNodeId -eq [string]$expected.sourceNodeId -and
                [string]$_.targetNodeId -eq [string]$expected.targetNodeId -and
                [string]$_.kind -eq 'content-derivation'
            }
            if (@($persisted).Count -ne 1) {
                throw "Pre-delete verification failed: expected exactly one content-derivation edge '$($expected.id)' with the supplied endpoints."
            }
        }
        $deleted = @()
        foreach ($expected in $manifestEdges) {
            $encodedEdgeId = [Uri]::EscapeDataString([string]$expected.id)
            $mutation = Invoke-Utf8JsonRequest `
                -Method DELETE `
                -Uri "$($config.baseUrl)/v1/edges/$encodedEdgeId" `
                -TimeoutSec 10
            Assert-ExactText $mutation.id ([string]$expected.id) 'deleted edge ID'
            $deleted += $mutation
        }
        $verifiedGraph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        foreach ($expected in $manifestEdges) {
            if (@($verifiedGraph.edges | Where-Object { [string]$_.id -eq [string]$expected.id }).Count -ne 0) {
                throw "Post-delete verification failed: edge '$($expected.id)' still exists."
            }
        }
        $response = [ordered]@{
            canvasId = [string]$manifest.canvasId
            deletedEdges = $deleted
            edgeCount = $deleted.Count
        }
    }
    elseif ($Action -eq 'DeleteContentVersion') {
        Require-Value $CanvasId 'CanvasId'
        Require-Value $NodeId 'NodeId'
        Require-Value $VersionId 'VersionId'
        $graphQuery = '?canvasId=' + [Uri]::EscapeDataString($CanvasId)
        $graph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        $node = @($graph.nodes) | Where-Object { [string]$_.id -eq $NodeId } | Select-Object -First 1
        if ($null -eq $node -or -not [bool]$node.content.contentNode) {
            throw "Pre-delete verification failed: '$NodeId' is not a content node in Canvas '$CanvasId'."
        }
        $versions = @($node.content.promptVersions)
        if ($versions.Count -le 1) {
            throw 'The only content version cannot be deleted.'
        }
        if (@($versions | Where-Object { [string]$_.id -eq $VersionId }).Count -ne 1) {
            throw "Pre-delete verification failed: version '$VersionId' is not on content node '$NodeId'."
        }
        $encodedNodeId = [Uri]::EscapeDataString($NodeId)
        $encodedVersionId = [Uri]::EscapeDataString($VersionId)
        $response = Invoke-Utf8JsonRequest `
            -Method DELETE `
            -Uri "$($config.baseUrl)/v1/content-nodes/$encodedNodeId/versions/$encodedVersionId" `
            -TimeoutSec 10
        Assert-ExactText $response.id $NodeId 'updated content node ID'
        $verifiedGraph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$graphQuery" `
            -TimeoutSec 10
        $verifiedNode = @($verifiedGraph.nodes) | Where-Object { [string]$_.id -eq $NodeId } | Select-Object -First 1
        if ($null -eq $verifiedNode -or @($verifiedNode.content.promptVersions | Where-Object { [string]$_.id -eq $VersionId }).Count -ne 0) {
            throw "Post-delete verification failed: version '$VersionId' still exists on node '$NodeId'."
        }
    }
    elseif ($Action -eq 'PlaceContentNodes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.canvasId)) {
            throw 'The UTF-8 placement manifest must contain canvasId.'
        }
        $placements = @($manifest.nodes)
        if ($placements.Count -eq 0) {
            throw 'The UTF-8 placement manifest must contain nodes.'
        }
        $updates = @()
        foreach ($placement in $placements) {
            if ([string]::IsNullOrWhiteSpace([string]$placement.id) -or $null -eq $placement.x -or $null -eq $placement.y) {
                throw 'Every placement must contain id, x, and y.'
            }
            $body = [ordered]@{
                id = [string]$placement.id
                x = [double]$placement.x
                y = [double]$placement.y
            } | ConvertTo-Json -Depth 4
            $updated = Invoke-Utf8JsonRequest `
                -Method POST `
                -Uri "$($config.baseUrl)/v1/nodes:update" `
                -Body $body `
                -TimeoutSec 10
            Assert-ExactText $updated.canvasId ([string]$manifest.canvasId) 'placement Canvas ID'
            Assert-ExactText $updated.id ([string]$placement.id) 'placement node ID'
            if ([Math]::Abs(([double]$updated.x) - ([double]$placement.x)) -gt 0.01 -or [Math]::Abs(([double]$updated.y) - ([double]$placement.y)) -gt 0.01) {
                throw "Placement verification failed for node '$($placement.id)'."
            }
            $updates += $updated
        }
        $response = [ordered]@{
            canvasId = [string]$manifest.canvasId
            nodes = $updates
            nodeCount = $updates.Count
        }
    }
    elseif ($Action -eq 'CloneContentNodes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $manifest = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($field in @('sourceCanvasId', 'targetCanvasId', 'requestId')) {
            if ([string]::IsNullOrWhiteSpace([string]$manifest.$field)) {
                throw "The UTF-8 clone manifest must contain $field."
            }
        }
        $sourceNodeIds = @($manifest.sourceNodeIds)
        if ($sourceNodeIds.Count -eq 0) {
            throw 'The UTF-8 clone manifest must contain sourceNodeIds.'
        }
        $sourceQuery = '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.sourceCanvasId)
        $sourceGraph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$sourceQuery" `
            -TimeoutSec 10
        $sourceById = @{}
        foreach ($node in @($sourceGraph.nodes)) { $sourceById[[string]$node.id] = $node }
        $source = if ([string]::IsNullOrWhiteSpace([string]$manifest.source)) { 'codex' } else { [string]$manifest.source }
        $createdAt = [DateTime]::UtcNow.ToString('o')
        $nodeInputs = @()
        $orderedSources = @()
        for ($index = 0; $index -lt $sourceNodeIds.Count; $index += 1) {
            $sourceNodeId = [string]$sourceNodeIds[$index]
            if (-not $sourceById.ContainsKey($sourceNodeId)) {
                throw "Source Canvas does not contain content node '$sourceNodeId'."
            }
            $sourceNode = $sourceById[$sourceNodeId]
            $activeVersionId = [string]$sourceNode.content.activePromptVersionId
            $activeVersion = @($sourceNode.content.promptVersions) | Where-Object { [string]$_.id -eq $activeVersionId } | Select-Object -First 1
            if ($null -eq $activeVersion) {
                throw "Source content node '$sourceNodeId' has no active version."
            }
            $contentType = [string]$sourceNode.content.contentType
            if (@('plot', 'script', 'storyboard', 'prompt') -notcontains $contentType) {
                throw "Source content node '$sourceNodeId' has invalid contentType '$contentType'."
            }
            $requestId = ([string]$manifest.requestId) + ':' + ($index + 1)
            $versionId = 'version:' + [Guid]::NewGuid().ToString('D')
            $version = [ordered]@{
                id = $versionId
                label = 'v1'
                title = [string]$activeVersion.title
                text = [string]$activeVersion.text
                information = [string]$activeVersion.information
                createdAt = $createdAt
                requestId = $requestId
                source = $source
            }
            if ($null -ne $activeVersion.referenceSelection) {
                $version.referenceSelection = $activeVersion.referenceSelection
            }
            if ($null -ne $activeVersion.generationOptions) {
                $version.generationOptions = $activeVersion.generationOptions
            }
            if ($null -ne $activeVersion.durationOverrideSeconds) {
                $version.durationOverrideSeconds = $activeVersion.durationOverrideSeconds
            }
            $content = [ordered]@{
                text = [string]$activeVersion.text
                information = [string]$activeVersion.information
                contentNode = $true
                contentType = $contentType
                promptVersions = @($version)
                activePromptVersionId = $versionId
                bestPromptVersionId = ''
            }
            if ($null -ne $activeVersion.referenceSelection) {
                $content.referenceSelection = $activeVersion.referenceSelection
            }
            if ($null -ne $activeVersion.generationOptions) {
                $content.generationOptions = $activeVersion.generationOptions
            }
            $nodeInputs += [ordered]@{
                canvasId = [string]$manifest.targetCanvasId
                kind = 'text'
                title = [string]$sourceNode.title
                content = $content
                source = $source
                requestId = $requestId
                width = [double]$sourceNode.width
                height = [double]$sourceNode.height
            }
            $orderedSources += $sourceNode
        }
        $body = @{ nodes = $nodeInputs } | ConvertTo-Json -Depth 64
        $batch = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/nodes:create-batch" `
            -Body $body `
            -TimeoutSec 30
        $mutations = @($batch.nodes)
        if ($mutations.Count -ne $orderedSources.Count) {
            throw 'Clone completeness verification failed.'
        }
        $mappings = @()
        for ($index = 0; $index -lt $mutations.Count; $index += 1) {
            $sourceNode = $orderedSources[$index]
            $targetNode = $mutations[$index].node
            Assert-ExactText $targetNode.canvasId ([string]$manifest.targetCanvasId) "clone $($index + 1) target Canvas"
            Assert-ExactText $targetNode.title ([string]$sourceNode.title) "clone $($index + 1) title"
            Assert-ExactText $targetNode.content.text ([string]$sourceNode.content.text) "clone $($index + 1) text"
            Assert-ExactText $targetNode.content.information ([string]$sourceNode.content.information) "clone $($index + 1) Information"
            Assert-ExactText $targetNode.content.contentType ([string]$sourceNode.content.contentType) "clone $($index + 1) type"
            $mappings += [ordered]@{
                sourceNodeId = [string]$sourceNode.id
                targetNodeId = [string]$targetNode.id
                title = [string]$targetNode.title
                created = [bool]$mutations[$index].created
            }
        }
        $targetQuery = '?canvasId=' + [Uri]::EscapeDataString([string]$manifest.targetCanvasId)
        $targetGraph = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/content-graph$targetQuery" `
            -TimeoutSec 10
        $targetIds = @($targetGraph.nodes | ForEach-Object { [string]$_.id })
        foreach ($mapping in $mappings) {
            if ($targetIds -notcontains [string]$mapping.targetNodeId) {
                throw "Post-write verification failed: target Canvas omitted clone '$($mapping.targetNodeId)'."
            }
        }
        $response = [ordered]@{
            sourceCanvasId = [string]$manifest.sourceCanvasId
            targetCanvasId = [string]$manifest.targetCanvasId
            nodes = $mappings
            createdCount = [int]$batch.createdCount
            existingCount = [int]$batch.existingCount
        }
    }
    elseif ($Action -eq 'CreateMissingScenes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $body = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8
        $manifest = $body | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.promptSetId)) {
            throw 'The UTF-8 manifest must contain promptSetId.'
        }
        foreach ($scene in @($manifest.scenes)) {
            $sceneKey = [string]$scene.sceneKey
            $sceneMatch = [regex]::Match($sceneKey, '^S0*([1-9][0-9]*)$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $sceneMatch.Success) {
                throw "Scene key '$sceneKey' is invalid. Use S01, S02, and other positive S-number keys."
            }
            $displayTitle = 'S' + ([int]$sceneMatch.Groups[1].Value)
            if ($null -eq $scene.PSObject.Properties['title']) {
                $scene | Add-Member -NotePropertyName title -NotePropertyValue $displayTitle
            }
            elseif ([string]::IsNullOrWhiteSpace([string]$scene.title)) {
                $scene.title = $displayTitle
            }
            Assert-PromptGenerationOptions -GenerationOptions $scene.generationOptions -Label "Scene $sceneKey generationOptions"
        }
        $body = $manifest | ConvertTo-Json -Depth 32
        $encodedPromptSetId = [Uri]::EscapeDataString([string]$manifest.promptSetId)
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes:create-missing" `
            -Body $body `
            -TimeoutSec 30

        $expectedScenes = @{}
        foreach ($scene in @($manifest.scenes)) {
            $expectedScenes[[string]$scene.sceneKey] = $scene
        }
        $responseScenes = @($response.scenes)
        if ($responseScenes.Count -ne $expectedScenes.Count) {
            throw "Completeness verification failed: expected $($expectedScenes.Count) scenes, but the response contained $($responseScenes.Count)."
        }
        $responseScenesByKey = @{}
        foreach ($mutation in $responseScenes) {
            $actualSceneKey = [string]$mutation.binding.sceneKey
            if ($responseScenesByKey.ContainsKey($actualSceneKey)) {
                throw "Completeness verification failed: response contained duplicate scene '$actualSceneKey'."
            }
            $responseScenesByKey[$actualSceneKey] = $mutation
        }
        foreach ($expectedSceneKey in $expectedScenes.Keys) {
            if (-not $responseScenesByKey.ContainsKey($expectedSceneKey)) {
                throw "Completeness verification failed: response omitted scene '$expectedSceneKey'."
            }
        }
        foreach ($mutation in @($response.scenes)) {
            if (-not [bool]$mutation.created) {
                continue
            }
            $actualSceneKey = [string]$mutation.binding.sceneKey
            if (-not $expectedScenes.ContainsKey($actualSceneKey)) {
                throw "UTF-8 round-trip verification failed: response contained unexpected scene '$actualSceneKey'."
            }
            $expectedScene = $expectedScenes[$actualSceneKey]
            Assert-ExactText $mutation.binding.sceneTitle ([string]$expectedScene.title) "$actualSceneKey binding title"
            Assert-ExactText $mutation.node.title ([string]$expectedScene.title) "$actualSceneKey node title"
            Assert-ExactText $mutation.node.content.sceneTitle ([string]$expectedScene.title) "$actualSceneKey content title"
            Assert-ExactText $mutation.node.content.text ([string]$expectedScene.text) "$actualSceneKey text"
            Assert-ExactText $mutation.node.content.information ([string]$expectedScene.information) "$actualSceneKey Information"
            $activeVersionId = [string]$mutation.node.content.activePromptVersionId
            $activeVersion = @($mutation.node.content.promptVersions) | Where-Object { [string]$_.id -eq $activeVersionId } | Select-Object -First 1
            if ($null -eq $activeVersion) {
                throw "UTF-8 round-trip verification failed: $actualSceneKey has no matching active version."
            }
            Assert-ExactText $activeVersion.title ([string]$expectedScene.title) "$actualSceneKey version title"
            Assert-ExactText $activeVersion.text ([string]$expectedScene.text) "$actualSceneKey version text"
            Assert-ExactText $activeVersion.information ([string]$expectedScene.information) "$actualSceneKey version Information"
        }

        $createdMutations = @($manifest.scenes | ForEach-Object {
            $mutation = $responseScenesByKey[[string]$_.sceneKey]
            if ([bool]$mutation.created) { $mutation }
        })
        if ($createdMutations.Count -ne [int]$response.createdCount) {
            throw "Completeness verification failed: createdCount does not match the returned created scenes."
        }
        if ($createdMutations.Count -gt 1) {
            $rowY = [double]$createdMutations[0].node.y
            for ($index = 1; $index -lt $createdMutations.Count; $index += 1) {
                $previous = $createdMutations[$index - 1].node
                $current = $createdMutations[$index].node
                if ([Math]::Abs(([double]$current.y) - $rowY) -gt 0.01) {
                    throw 'Layout verification failed: created prompt scenes are not on one horizontal row.'
                }
                if ([double]$current.x -le ([double]$previous.x + [double]$previous.width)) {
                    throw 'Layout verification failed: created prompt scenes are not ordered left-to-right without overlap.'
                }
            }
        }

        # The open Canvas may relocate a newly created batch from its provisional
        # database row to the current viewport before persisting final coordinates.
        Start-Sleep -Milliseconds 300
        $persisted = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes" `
            -TimeoutSec 10
        $persistedByKey = @{}
        foreach ($binding in @($persisted.scenes)) {
            $persistedByKey[[string]$binding.sceneKey] = $binding
        }
        foreach ($expectedSceneKey in $expectedScenes.Keys) {
            if (-not $persistedByKey.ContainsKey($expectedSceneKey)) {
                throw "Post-write verification failed: persisted bindings omitted scene '$expectedSceneKey'."
            }
            $mutation = $responseScenesByKey[$expectedSceneKey]
            $binding = $persistedByKey[$expectedSceneKey]
            Assert-ExactText $binding.nodeId ([string]$mutation.binding.nodeId) "$expectedSceneKey persisted node ID"
            if ([bool]$mutation.created) {
                Assert-ExactText $binding.latestVersion 'v1' "$expectedSceneKey persisted latest version"
                if ([int]$binding.versionCount -ne 1) {
                    throw "Post-write verification failed: $expectedSceneKey versionCount is not 1."
                }
            }
        }
        $persistedCreated = @($manifest.scenes | ForEach-Object {
            $mutation = $responseScenesByKey[[string]$_.sceneKey]
            if ([bool]$mutation.created) { $persistedByKey[[string]$_.sceneKey] }
        })
        if ($persistedCreated.Count -gt 1) {
            $rowY = [double]$persistedCreated[0].y
            for ($index = 1; $index -lt $persistedCreated.Count; $index += 1) {
                $previous = $persistedCreated[$index - 1]
                $current = $persistedCreated[$index]
                if ([Math]::Abs(([double]$current.y) - $rowY) -gt 0.01) {
                    throw 'Post-write layout verification failed: persisted prompt scenes are not on one horizontal row.'
                }
                if ([double]$current.x -le ([double]$previous.x + [double]$previous.width)) {
                    throw 'Post-write layout verification failed: persisted prompt scenes are not ordered left-to-right without overlap.'
                }
            }
        }
    }
    elseif ($Action -eq 'AppendContentVersion') {
        Require-Value $NodeId 'NodeId'
        Require-Value $RequestId 'RequestId'
        $referenceSelection = $null
        $generationOptions = $null
        if (-not [string]::IsNullOrWhiteSpace($PromptPackagePath)) {
            if (-not [string]::IsNullOrEmpty($Path) -or -not [string]::IsNullOrEmpty($InformationPath) -or -not [string]::IsNullOrEmpty($Text) -or -not [string]::IsNullOrEmpty($Information) -or -not [string]::IsNullOrEmpty($Title) -or -not [string]::IsNullOrEmpty($TitlePath)) {
                throw 'AppendContentVersion accepts either -PromptPackagePath or separate text, Information, and title inputs, not both.'
            }
            $package = Read-PromptPackage -FilePath $PromptPackagePath
            $finalText = [string]$package.text
            $finalInformation = [string]$package.information
            $finalTitle = if ($null -ne $package.PSObject.Properties['title']) { [string]$package.title } else { '' }
            $referenceSelection = $package.referenceSelection
            $generationOptions = $package.generationOptions
        }
        else {
            Require-Value $Path 'Path (UTF-8 content file)'
            Require-Value $InformationPath 'InformationPath (UTF-8 Information file)'
            if (-not [string]::IsNullOrEmpty($Text) -or -not [string]::IsNullOrEmpty($Information)) {
                throw 'AppendContentVersion accepts text and Information only through -Path and -InformationPath UTF-8 files.'
            }
            if (-not [string]::IsNullOrEmpty($Title) -and [string]::IsNullOrEmpty($TitlePath)) {
                throw 'Pass an explicit version title through -TitlePath as a UTF-8 file.'
            }
            $finalText = Read-Utf8Text -FilePath $Path -Label 'Text' -Required
            $finalInformation = Read-Utf8Text -FilePath $InformationPath -Label 'Information'
            $finalTitle = Read-Utf8Text -InlineValue $Title -FilePath $TitlePath -Label 'Title'
        }
        if (-not [string]::IsNullOrEmpty($finalTitle)) {
            $finalTitle = $finalTitle.TrimEnd([char[]]"`r`n")
        }
        $json = '{"text":"' + (ConvertTo-JsonString $finalText) +
            '","information":"' + (ConvertTo-JsonString $finalInformation) +
            '","source":"' + (ConvertTo-JsonString $Source) +
            '","requestId":"' + (ConvertTo-JsonString $RequestId) + '"'
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            $json += ',"title":"' + (ConvertTo-JsonString $finalTitle) + '"'
        }
        if ($ExpectedVersionCount -ge 0) {
            $json += ',"expectedVersionCount":' + $ExpectedVersionCount
        }
        if ($null -ne $referenceSelection) {
            $json += ',"referenceSelection":' + ($referenceSelection | ConvertTo-Json -Depth 32 -Compress)
        }
        if ($null -ne $generationOptions) {
            $json += ',"generationOptions":' + ($generationOptions | ConvertTo-Json -Depth 8 -Compress)
        }
        $json += '}'
        $encodedNodeId = [Uri]::EscapeDataString($NodeId)
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/content-nodes/$encodedNodeId/versions:append" `
            -Body $json `
            -TimeoutSec 30

        Assert-ExactText $response.node.id $NodeId 'content node ID'
        Assert-ExactText $response.version.text $finalText 'content version text'
        Assert-ExactText $response.version.information $finalInformation 'content version Information'
        Assert-ExactText $response.node.content.activePromptVersionId ([string]$response.version.id) 'active content version ID'
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            Assert-ExactText $response.version.title $finalTitle 'content version title'
        }
    }
    else {
        Require-Value $PromptSetId 'PromptSetId'
        Require-Value $SceneKey 'SceneKey'
        Require-Value $RequestId 'RequestId'
        $referenceSelection = $null
        $generationOptions = $null
        if (-not [string]::IsNullOrWhiteSpace($PromptPackagePath)) {
            if (-not [string]::IsNullOrEmpty($Path) -or -not [string]::IsNullOrEmpty($InformationPath) -or -not [string]::IsNullOrEmpty($Text) -or -not [string]::IsNullOrEmpty($Information) -or -not [string]::IsNullOrEmpty($Title) -or -not [string]::IsNullOrEmpty($TitlePath)) {
                throw 'AppendVersion accepts either -PromptPackagePath or separate prompt, Information, and title inputs, not both.'
            }
            $package = Read-PromptPackage -FilePath $PromptPackagePath
            $finalText = [string]$package.text
            $finalInformation = [string]$package.information
            $finalTitle = if ($null -ne $package.PSObject.Properties['title']) { [string]$package.title } else { '' }
            $referenceSelection = $package.referenceSelection
            $generationOptions = $package.generationOptions
        }
        else {
            Require-Value $Path 'Path (UTF-8 prompt file)'
            Require-Value $InformationPath 'InformationPath (UTF-8 Information file)'
            if (-not [string]::IsNullOrEmpty($Text) -or -not [string]::IsNullOrEmpty($Information)) {
                throw 'AppendVersion accepts prompt text and Information only through -Path and -InformationPath UTF-8 files.'
            }
            if (-not [string]::IsNullOrEmpty($Title) -and [string]::IsNullOrEmpty($TitlePath)) {
                throw 'Pass an explicit title through -TitlePath as a UTF-8 file.'
            }
            $finalText = Read-Utf8Text -FilePath $Path -Label 'Text' -Required
            $finalInformation = Read-Utf8Text -FilePath $InformationPath -Label 'Information'
            $finalTitle = Read-Utf8Text -InlineValue $Title -FilePath $TitlePath -Label 'Title'
        }
        if (-not [string]::IsNullOrEmpty($finalTitle)) {
            $finalTitle = $finalTitle.TrimEnd([char[]]"`r`n")
        }
        $json = '{"text":"' + (ConvertTo-JsonString $finalText) +
            '","information":"' + (ConvertTo-JsonString $finalInformation) +
            '","source":"' + (ConvertTo-JsonString $Source) +
            '","requestId":"' + (ConvertTo-JsonString $RequestId) + '"'
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            $json += ',"title":"' + (ConvertTo-JsonString $finalTitle) + '"'
        }
        if ($ExpectedVersionCount -ge 0) {
            $json += ',"expectedVersionCount":' + $ExpectedVersionCount
        }
        if ($null -ne $referenceSelection) {
            $json += ',"referenceSelection":' + ($referenceSelection | ConvertTo-Json -Depth 32 -Compress)
        }
        if ($null -ne $generationOptions) {
            $json += ',"generationOptions":' + ($generationOptions | ConvertTo-Json -Depth 8 -Compress)
        }
        $json += '}'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $encodedSceneKey = [Uri]::EscapeDataString($SceneKey)
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes/$encodedSceneKey/versions:append" `
            -Body $json `
            -TimeoutSec 30

        Assert-ExactText $response.version.text $finalText "$SceneKey version text"
        Assert-ExactText $response.version.information $finalInformation "$SceneKey version Information"
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            Assert-ExactText $response.version.title $finalTitle "$SceneKey version title"
            Assert-ExactText $response.binding.sceneTitle $finalTitle "$SceneKey binding title"
            Assert-ExactText $response.node.title $finalTitle "$SceneKey node title"
        }
    }
}
catch {
    $details = $_.ErrorDetails.Message
    if ([string]::IsNullOrWhiteSpace($details)) {
        $details = $_.Exception.Message
    }
    throw "InfiniteCanvas prompt scene request failed. Make sure the app is running and the target binding is current. $details"
}

$response | ConvertTo-Json -Depth 32
