# Prompt scene operations

Use stable ASCII identifiers. Keep `promptSetId` unchanged for one storyboard or prompt project, and use zero-padded scene keys such as `S01`, `S02`, ... `S10`.

## Create only missing scenes

Write a UTF-8 JSON manifest and pass it to `manage-prompt-scenes.ps1 -Action CreateMissingScenes -ManifestPath`:

```json
{
  "promptSetId": "commercial-001",
  "promptSetTitle": "广告分镜",
  "source": "codex",
  "requestId": "unique-batch-request-id",
  "scenes": [
    {
      "sceneKey": "S01",
      "title": "场景1",
      "text": "Complete English prompt",
      "information": "完整中文解释"
    }
  ]
}
```

`canvasId` is optional. For a new prompt set, omission targets the Canvas project that is active when the request arrives. An existing prompt set always keeps its persisted project binding. Existing scene keys are returned unchanged; only missing keys are created with `v1`.

## Append one version

Query the current binding first. Then call `AppendVersion` with the returned `versionCount` as `-ExpectedVersionCount`. The request creates the next numeric label after the highest remaining label, so deleting `v2` does not cause a later version to reuse that label.

Keep one stable `RequestId` for retries of the same write. A repeated successful request returns `created: false`. Reusing that ID for another scene, or submitting a stale expected version count, returns HTTP 409 and must not be retried with a new ID until the binding is queried again.

## Responses

- `ListPromptSets` returns all persisted prompt sets across Canvas projects.
- `GetSceneBindings` returns the prompt set summary and ordered scene bindings.
- Each binding includes `promptSetId`, `canvasId`, `sceneKey`, `nodeId`, `latestVersion`, and `versionCount`.
- Create and append responses include the affected node records. Never print or expose the bearer token from `api.json`.
