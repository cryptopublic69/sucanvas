# Prompt scene operations

This is the skill's only node-writing workflow. Never fall back to the generic text-node API or direct database edits. Use stable ASCII identifiers. Keep `promptSetId` unchanged for one storyboard or prompt project, and use zero-padded scene keys such as `S01`, `S02`, ... `S10`. The default visible titles are compact (`S1`, `S2`, ...), but an explicit UTF-8 manifest title such as `轮回 S1` is preserved exactly. Visible titles are labels, never identities; resolve every target by `promptSetId + sceneKey`.

## Create only missing scenes

Write a UTF-8 JSON manifest and pass it to `manage-prompt-scenes.ps1 -Action CreateMissingScenes -ManifestPath`:

```json
{
  "promptSetId": "commercial-001",
  "promptSetTitle": "广告分镜",
  "source": "codex",
  "requestId": "unique-batch-request-id",
  "scenes": [
    {
      "sceneKey": "S01",
      "title": "S1",
      "text": "Complete English prompt",
      "information": "完整中文解释"
    }
  ]
}
```

`canvasId` is optional. For a new prompt set, omission targets the Canvas project that is active when the request arrives. An existing prompt set always keeps its persisted project binding. Existing scene keys are returned unchanged; only missing keys are created with `v1`. The management script derives a default display title only when `title` is missing or blank (`S01` -> `S1`); otherwise it preserves the manifest title exactly. It rejects scene keys that do not match `S` followed by a positive integer.

The manifest must be read from a UTF-8 file. The management script serializes it to strict UTF-8 bytes, decodes the API response from strict UTF-8 bytes, and compares every newly created title, prompt, and Information value with ordinal string equality. A mismatch is an uncertain write and must not be retried with a new request ID.

## Append one version

Query the current binding first. Then call `AppendVersion` with the returned `versionCount` as `-ExpectedVersionCount`. The request creates the next numeric label after the highest remaining label, so deleting `v2` does not cause a later version to reuse that label.

Pass the finished prompt and Information only through UTF-8 files using `-Path` and `-InformationPath`. For an explicit multilingual title, use `-TitlePath`. Inline prompt, Information, and Chinese title arguments are intentionally rejected so the shell's default encoding cannot corrupt them. The response must contain exactly the submitted strings before the operation is reported as successful.

Keep one stable `RequestId` for retries of the same write. A repeated successful request returns `created: false`. Reusing that ID for another scene, or submitting a stale expected version count, returns HTTP 409 and must not be retried with a new ID until the binding is queried again.

## Responses

- `ListPromptSets` returns all persisted prompt sets across Canvas projects.
- `GET /v1/prompt-sets?activeCanvasOnly=true` returns only the prompt sets for the Canvas currently open in the running app. The management script exposes this as `ListPromptSets -ActiveCanvas`.
- `GetSceneBindings` returns the prompt set summary and ordered scene bindings.
- Each binding includes `promptSetId`, `canvasId`, `sceneKey`, `nodeId`, `latestVersion`, and `versionCount`.
- Create and append responses include the affected node records. Never print or expose the bearer token from `api.json`.
