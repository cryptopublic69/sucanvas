---
name: send-to-infinite-canvas
description: Send approved text unchanged to the user's local InfiniteCanvas as typed, versioned Content Iteration nodes or scene-bound generation-prompt nodes. Create and query 剧情概念, 剧本, 分镜, and 生成提示词 content; preserve exact UTF-8 text and Information; batch-place new nodes in the current visible Canvas; recover persisted content relationships; and append conflict-protected versions with exact upstream-version provenance. Use when the user asks to send, push, add, place, save, continue, connect, query, or update creative text in InfiniteCanvas. Do not generate, rewrite, translate, review, optimize, or bulk-rename either field.
---

# Send to InfiniteCanvas

Send user-approved content unchanged to the running local InfiniteCanvas app. Keep writing and prompt generation in the producing skill; use this skill only to discover, create, and version Canvas content.

Read [references/prompt-scenes-api.md](references/prompt-scenes-api.md) before every write or query.

## Route by content role

Use one Content Iteration node model with these `contentType` values:

- `plot`: 剧情概念 or story-level material.
- `script`: 剧本 or scene script material.
- `storyboard`: 分镜 or director/storyboard material. The five top-level `场景1` through `场景5` nodes belong here.
- `prompt`: final generation prompts such as H3 segments.

For剧情概念、剧本、分镜, use `CreateContentNodes`, `ListContentGraph`, `CreateContentEdges`, and `AppendContentVersion`. Do not assign fake prompt-set identities.

## Route content stages before writing

Treat `plot → script → storyboard → prompt` as distinct creative artifacts, not as successive versions of one node. First determine whether the approved text revises the current artifact or advances it to a downstream stage:

- Create a new typed node when the content type changes, then create a `content-derivation` edge from the upstream node to the new node. A剧情概念 developed into a treatment, structural design, scene plan, or formatted screenplay belongs in `script`; a script developed into shots belongs in `storyboard`; a storyboard developed into executable generation text belongs in `prompt`.
- Append a version only when the same creative work remains identifiable: its core premise, central characters and relationship network, principal setting, and conflict mechanism remain substantially unchanged. Revisions, alternate tellings, and refinements under those conditions belong to the same typed node. Never append a script, storyboard, or prompt version to its upstream剧情概念 node.
- Create a new `plot` node when a proposed “new version” changes the story concept itself—for example, it replaces the premise, central characters or relationship network, principal setting, or core conflict/reversal mechanism. Treat it as an independent 剧情概念, not a `v2`, even if its genre, theme, scale, or a few motifs overlap with an existing concept. Do not connect two independent concepts merely because they were brainstormed together; connect each concept only to material genuinely derived from it.
- If a concept was mistakenly appended before this distinction was recognized, create the independent `plot` node from the exact misfiled version, reconnect only its real downstream materials, then use `DeleteContentVersion` to remove the misfiled version from the original concept. Do not merely switch which version is active or leave the erroneous version in its history.
- When the user says only “write it to Canvas”, infer the target type from the artifact just approved. After an explicit request to turn a concept into a script, all resulting script-stage material belongs in a new `script` node even when it is an outline rather than a final formatted screenplay.
- Preserve the upstream node and its active version. Query the graph immediately before creation, then verify both the new node and its exact derivation edge after writing. `CreateContentEdges` captures each new edge's upstream active version into the target active version's `derivedFrom`; this applies whether or not the edge requests layout placement. If a pre-existing edge was restored without that capture and the UI filters the target to “没有对应版本”, repair it by deleting and recreating that exact edge through the sender after confirming the intended upstream active version. Do not alter the target text, Information, title, version ID, position, or unrelated edges.

For H3 or other generation prompts that require stable scene bindings, continue using `CreateMissingScenes`, `ListPromptSets`, `GetSceneBindings`, and `AppendVersion`. Bind by `promptSetId + sceneKey`, never by title or position.

When writing smart H3 prompt scenes that were compiled from a storyboard, require the caller to provide the exact upstream storyboard Content Iteration node ID. After `CreateMissingScenes`, query the active content graph and create one `content-derivation` edge from that upstream storyboard node to each newly created prompt-scene node through `CreateContentEdges`. This is mandatory; do not treat prompt-set membership, visual proximity, title similarity, or a source generator ID as lineage. The sender captures that upstream active version into every created target version. The prompt-scene batch is already positioned, so omit `layoutPlacement` when adding these edges. Verify exactly one persisted edge per newly created scene and the matching `derivedFrom` entry; if the upstream node ID is unavailable, stop before writing. Do not duplicate edges when only appending a version to an existing prompt scene.

Never create ordinary text nodes. Every created node must contain `contentNode: true`, a valid `contentType`, and at least one version.

## Version Information by content type

Treat the `information` field differently for content revisions and generation prompts:

- For a new `plot`, `script`, or `storyboard` node at `v1`, preserve any user-supplied Information exactly; do not invent a revision note.
- Before appending `v2` or later to a `plot`, `script`, or `storyboard` node, read its active version and write a concise Chinese revision note in `information` that states only the material changes introduced by the new version. Start with `本次修改：`; name the changed people, story facts, structure, dialogue, shots, or other changed elements precisely. Do not describe unchanged content, add rationale, or call it a Chinese explanation.
- For `prompt` content nodes and every generation prompt set (including H3), `information` remains the complete Chinese explanation of the English prompt. Never replace it with a revision note.
- Do not mix the two purposes in the same `information` value. Determine the target node's `contentType` from `ListContentGraph` immediately before appending, rather than inferring it from the title.

## Query the active content graph

Run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action ListContentGraph
```

Pass `-CanvasId '<exact-id>'` to query a known Canvas even when it is not currently open.

The result contains the active Canvas's typed content nodes and persisted `content-derivation` edges. Use node IDs and active version IDs from this result. Never infer relationships from visual proximity, coordinates, titles, chat memory, or array order.

Users may manually connect any content node to another content node. The persisted edge is meaningful database state. Multiple upstream parents are allowed; cycles are rejected. When appending a downstream version, the server records every connected upstream node's active version in that new version's `derivedFrom` field.

## Read the current Canvas selection

When the user asks to act on the element currently selected in the open Canvas, run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action GetCanvasSelection
```

Treat the returned `canvasId` and `nodes[]` as transient UI context only. It is not persisted Canvas data, and an empty `nodes` list means nothing is selected. Do not infer selection from visual coordinates, graph relationships, or recent user wording.

To create verified relationships programmatically, write a UTF-8 manifest with an exact Canvas ID and run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateContentEdges `
  -ManifestPath 'D:\path\content-edges.json'
```

Each entry must contain `sourceNodeId` and `targetNodeId`; the source is the upstream content and the target is its downstream derivative. For a newly uploaded downstream node, also set `layoutPlacement: "right-of-source"`: it keeps that new node on the upstream node's horizontal row with a clear gap and records the upstream active version as the new node's initial-version provenance. Do not set this placement field when repairing a relationship between existing, manually arranged nodes. The script uses `content-derivation`, rejects cross-Canvas relationships and cycles, and verifies every persisted edge by exact node IDs. If source content lives in another Canvas, create an exact typed copy in the target Canvas first; never connect a folder merely because it visually contains the source.

To repair an incorrect content relationship, never leave the obsolete edge alongside a replacement. Query the graph, then use `DeleteContentEdges` with a UTF-8 manifest containing the exact `canvasId` and, for every edge, its `id`, `sourceNodeId`, and `targetNodeId`. The operation verifies the persisted `content-derivation` edge before deletion and confirms it is absent afterward. Create the corrected edge separately, then query the graph again to verify the final topology.

## Create typed content nodes

Write one UTF-8 manifest and run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateContentNodes `
  -ManifestPath 'D:\path\content-nodes.json'
```

Manifest:

```json
{
  "contentType": "storyboard",
  "source": "codex",
  "requestId": "stable-project-storyboards-v1",
  "nodes": [
    {
      "title": "场景1",
      "text": "完整分镜文本",
      "information": ""
    }
  ]
}
```

Each node may override the manifest-level `contentType`. Preserve explicit titles exactly. Apply these defaults only when the user has not supplied a title:

- Top-level story scenes: `场景1`, `场景2`, ...
- H3 or other generation segments: `S1`, `S2`, ...

Use a stable ASCII `requestId` for idempotent retries. The operation creates one `v1` per node and publishes all new nodes as one batch. The app must place the batch left-to-right on one horizontal row in the currently visible Canvas region and avoid existing nodes. The script verifies exact text, Information, type, active `v1`, graph persistence, and final layout. If any check fails, report the write as uncertain or incomplete.

Always include the exact target `canvasId` in a creation manifest unless the user explicitly requests the currently active Canvas. If a content node is created in the wrong Canvas, use `DeleteContentNodes` with its exact `canvasId` and `id` after verifying the graph; do not leave an unintended duplicate behind.

When approved content already exists in another Canvas, use `CloneContentNodes` with a UTF-8 manifest containing `sourceCanvasId`, `targetCanvasId`, a stable `requestId`, and ordered `sourceNodeIds`. This creates exact active-version copies in the target Canvas without rewriting text, Information, type, title, or reference selection, and returns durable source-to-target node mappings for subsequent relationships.

Use `PlaceContentNodes` with exact node IDs and coordinates when copied content must be arranged beside its upstream node. Verify the Canvas ID and final coordinates; change no content during placement.

## Append a version to typed content

Query `ListContentGraph` immediately before writing. Determine the target node's `contentType`, count its current `promptVersions`, and for a `plot`、`script`、or `storyboard` `v2+` prepare the required Chinese `本次修改：...` revision note as the UTF-8 Information file. For `prompt`, keep the Information as the English prompt's complete Chinese explanation. Then run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action AppendContentVersion `
  -NodeId 'node:exact-id' `
  -Path 'D:\path\content.txt' `
  -InformationPath 'D:\path\information.txt' `
  -ExpectedVersionCount 1 `
  -Source 'codex' `
  -RequestId 'stable-content-version-request'
```

Pass an optional multilingual version title through `-TitlePath`. The node's visible title is unchanged. A successful append activates the next numeric version and automatically captures exact upstream provenance. For several target nodes, use one request per node with distinct stable request IDs and each node's own expected count.

If the API returns HTTP 409, stop and query again. Do not bypass the conflict by changing the request ID.

## Work with generation prompt sets

If `promptSetId` is unknown, run `ListPromptSets`; add `-ActiveCanvas` when the user means the currently open Canvas. Then run `GetSceneBindings -PromptSetId '<id>'`.

Create missing bound prompts with a UTF-8 manifest and:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateMissingScenes `
  -ManifestPath 'D:\path\prompt-scenes.json'
```

Use zero-padded stable keys such as `S01`, while preserving the explicit visible title independently. For a smart H3 prompt package, keep each package's `sceneKey`、`title`、`text`、`information`、`generationOptions.durationSeconds`、`referenceSelection` together; do not split its internal selection or duration parameter from its prompt. `generationOptions.durationSeconds` is an integer from 2 through 15 and is the visible initial recommendation in the Canvas generation-prompt version. A user may later save a per-version manual duration override in Canvas; preserve it on clone, but do not invent or overwrite it when sending a new package. Neither value may be copied into the English prompt, Chinese Information, or reference selection. Before appending an existing smart H3 version through `AppendVersion -PromptPackagePath`, query that bound node's `content-derivation` edges and resolve every source node's current active version. The append must return matching `derivedFrom` entries; otherwise treat the write as failed and do not claim that the new version is usable. Pass the binding's current `versionCount` through `-ExpectedVersionCount`. If the installed sender/API cannot preserve and return `generationOptions.durationSeconds` or upstream provenance as part of the same prompt version, stop before writing and report that the Canvas integration requires implementation; never silently discard either value or substitute the generator's 10-second default. Ordinary prompts continue to use UTF-8 prompt and Information files.

Keep top-level content nodes separate from downstream generation prompt sets. Do not store剧情、剧本或分镜 as fake H3 scene bindings merely to reuse `S01` keys.

## Integrity rules

- Preserve body and explicit title string-for-string. Preserve Information exactly when it is user-supplied or is the required Chinese explanation for a generation prompt; for `plot`、`script`、and `storyboard` `v2+`, write the required revision note instead. Add no headings, fences, translations, or formatting to the body.
- For every `plot`、`script`、or `storyboard` revision, verify after writing that the active version's Information begins with `本次修改：` and accurately names the actual changes from its immediate prior version. Do not apply this check to `prompt` nodes or prompt sets.
- For MiniMax H3, keep the complete English executable prompt in `text`, its complete Chinese explanation in `information`, the exact selected assets in `referenceSelection`, and the independently selected `generationOptions.durationSeconds` in the same version. A smart H3 prompt package is the only accepted hand-off form between the smart-prompt skill and this sender.
- Use strict UTF-8 files for multilingual inputs. Never pass Chinese text inline on the command line.
- Use the bundled script. Never use `Invoke-RestMethod`, shell-default encoding, direct SQLite edits, or ad-hoc HTTP writes.
- Treat a backend rejection mentioning `likely UTF-8 mojibake` as a hard safety stop: do not retry, transform, or overwrite with the returned string. Re-read the approved UTF-8 source artifact, then use the scoped repair flow only after identifying the exact node and version IDs.
- If an existing prompt version's title or Information is confirmed as mojibake, repair only those exact persisted fields through `RepairPromptSceneVersionMetadata` and a UTF-8 manifest. Verify the exact Canvas, `promptSetId + sceneKey`, node ID, existing version IDs, restored strings, and intended active version before and after the repair. Do not create an unnecessary new version or alter its prompt text, reference selection, duration, lineage, geometry, or unrelated metadata.
- If an existing prompt-scene version is hidden because its persisted `derivedFrom` is missing or stale, use `RepairPromptSceneVersionLineage` with the exact Canvas ID, `promptSetId + sceneKey`, node ID, and existing version ID. By default it resolves every incoming `content-derivation` edge to the upstream node's current active version. When continuing a downstream version that must retain its own older source, pass the exact persisted `-LineageSourceVersionId`; the script verifies that version belongs to the connected upstream node before replacing only that version's lineage. It makes that existing version active and verifies the returned `{nodeId, versionId, versionLabel}` entries. Never infer an upstream version from titles or change prompt text, Information, reference selection, duration, geometry, or unrelated metadata.
- Keep the same request ID when retrying an uncertain operation. Never retry with a new ID until state is queried.
- Use `source: codex` for Codex output and `source: reasonix` for Reasonix output unless the user specifies another source.
- Never expose the token read from `%LOCALAPPDATA%\InfiniteCanvas\api.json`.
- If the app or the required API is unavailable, ask the user to start the updated InfiniteCanvas build and retry.
