# InfiniteCanvas content operations

## Typed content graph

`GET /v1/content-graph` returns the active Canvas snapshot filtered to Content Iteration nodes and `content-derivation` edges. Pass `?canvasId={exactCanvasId}` to query a known Canvas explicitly. A node is recognized by `contentNode: true`; legacy flags remain readable during migration. Relationships are persisted edges, not visual decoration.

Valid content types:

- `plot`: 剧情概念
- `script`: 剧本
- `storyboard`: 分镜
- `prompt`: 生成提示词

## Batch-create content nodes

`POST /v1/nodes:create-batch` accepts:

```json
{
  "nodes": [
    {
      "kind": "text",
      "title": "场景1",
      "content": {
        "text": "完整分镜文本",
        "information": "",
        "contentNode": true,
        "contentType": "storyboard",
        "promptVersions": [
          {
            "id": "version:uuid",
            "label": "v1",
            "title": "场景1",
            "text": "完整分镜文本",
            "information": "",
            "createdAt": "ISO-8601 timestamp",
            "requestId": "stable-request:1",
            "source": "codex"
          }
        ],
        "activePromptVersionId": "version:uuid",
        "bestPromptVersionId": ""
      },
      "source": "codex",
      "requestId": "stable-request:1",
      "width": 460,
      "height": 320
    }
  ]
}
```

Omit `canvasId` to target the Canvas active when the request arrives. Each node request ID is independently idempotent. The server emits all newly created nodes as one batch so the frontend can center and arrange them together. Verify returned content exactly, then query `/v1/content-graph` after the frontend has persisted final coordinates.

`CloneContentNodes` is a script-level operation built on the same batch endpoint. It reads exact source nodes through a source-Canvas content graph, creates fresh `v1` versions with stable target request IDs, preserves the active text, Information, title, content type, and reference selection, then returns source-to-target node ID mappings.

## Append a typed content version

`POST /v1/content-nodes/{nodeId}/versions:append` accepts the same body fields as prompt-scene append:

```json
{
  "text": "revised content",
  "information": "matching Information",
  "title": "optional version title",
  "source": "codex",
  "requestId": "stable-version-request",
  "expectedVersionCount": 1
}
```

The node must be a Content Iteration node. The request activates the next numeric version. It captures all incoming content relationships as exact `{nodeId, versionId, versionLabel}` entries in `derivedFrom`. Reusing the same request returns `created: false`; a stale version count or request-ID collision returns HTTP 409.

## Create a content relationship

`POST /v1/edges` accepts an exact `canvasId`, `sourceNodeId`, `targetNodeId`, `kind: "content-derivation"`, and relationship metadata. The bundled sender sets `captureInitialVersionSources: true` for every newly created content relationship, which locks the upstream active version into the new downstream node's active version. Set metadata `layoutPlacement: "right-of-source"` only for a newly uploaded downstream node: after the relationship is created, its persisted position becomes the upstream node's right side with a 60px gap and the same vertical coordinate. Provenance capture and placement are applied only when the relationship itself is new, so idempotent retries do not override a later manual arrangement. Both nodes must be Content Iteration nodes in the same Canvas. The database returns an existing identical relationship instead of duplicating it, permits multiple upstream parents, and rejects cycles. Query the exact Canvas content graph afterward and require exactly one matching relationship plus the matching `derivedFrom` version source.

## Delete a content relationship

`DELETE /v1/edges/{edgeId}` requires bearer authentication and returns `{ "id": "edge:..." }`. Use only through `DeleteContentEdges`: it first verifies that the exact edge ID and supplied endpoints identify a persisted `content-derivation` relationship in the specified Canvas, then confirms removal from the content graph.

## Delete a content node

`DELETE /v1/nodes/{nodeId}` requires bearer authentication and returns `{ "id": "node:..." }`. Use only through `DeleteContentNodes`: it verifies the node is a persisted Content Iteration node in the supplied Canvas and confirms removal from the content graph.

## Delete a content version

`DELETE /v1/content-nodes/{nodeId}/versions/{versionId}` requires bearer authentication and returns the updated node. The operation rejects removal of the only version, deletes the associated idempotency record, and restores the active text, Information, reference selection, and active version ID from a remaining version when needed. Use only through `DeleteContentVersion`, which checks the exact Canvas, node, and version before and after the mutation.

## Generation prompt sets

Prompt-set APIs remain for final generation prompts that need stable scene identities:

- `GET /v1/prompt-sets`
- `GET /v1/prompt-sets?activeCanvasOnly=true`
- `GET /v1/prompt-sets/{promptSetId}/scenes`
- `POST /v1/prompt-sets/{promptSetId}/scenes:create-missing`
- `POST /v1/prompt-sets/{promptSetId}/scenes/{sceneKey}/versions:append`

Use `promptSetId + sceneKey` as durable identity. Visible titles are labels only. Use zero-padded stable scene keys such as `S01`, but preserve explicit UTF-8 titles exactly. Do not use prompt sets for ordinary剧情、剧本或分镜 content.

All writes must use strict UTF-8 bytes, bearer authentication from local `api.json`, stable request IDs, exact response verification, and no direct database edits.

## Current Canvas selection

`GET /v1/canvas-selection` returns the live UI selection for the currently open Canvas. It returns `canvasId`、`nodeIds`、`nodes[]` (`id`、`kind`、`title`) and `updatedAt`. This state is memory-only: it is cleared when the Canvas changes and is never written to SQLite. An empty `nodes` array means no current selection.

## Smart H3 prompt packages

For a smart-video-generation scene, use one `infinite-canvas-h3-prompt-package/v1` object containing `sceneKey`、`title`、`text`、`information`、`generationOptions.durationSeconds`、`referenceSelection`. The stored fields are inseparable: `text` is the H3 prompt, `information` is user-facing Chinese explanation, `generationOptions.durationSeconds` is the independently selected 2–15 second initial recommendation, and `referenceSelection` selects exactly which noted image/audio/video assets are uploaded. Canvas may persist a user-owned per-version duration override that takes precedence at execution; it does not change this package's English text, Chinese Information, or reference selection. Do not place duration in `text`、`information` or `referenceSelection`; do not default it to 10 seconds.

- New scenes: put those six fields together in the `scenes[]` manifest entry passed to `CreateMissingScenes`.
- Existing scene versions: save one package as UTF-8 JSON and call `AppendVersion -PromptPackagePath '<package.json>'`. Do not separately pass `-Path` or `-InformationPath`.
- Existing Content Iteration versions use the equivalent `AppendContentVersion -PromptPackagePath` form.
