---
name: send-to-infinite-canvas
description: Send finished text unchanged to the user's local InfiniteCanvas app exclusively as scene-bound Prompt Iteration nodes titled S1, S2, S3, and so on, with paired English prompt text and Chinese Information. Query and recover prompt-set bindings after a new conversation, create only missing scenes, and append a new version to an exact scene such as S2 or S5 with idempotency and version-conflict protection. Use when the user asks to send, push, add, place, save, continue, or update generated prompts or text in InfiniteCanvas. Do not create generic text nodes, and do not generate, rewrite, translate, review, or optimize either field.
---

# Send to InfiniteCanvas

Send user-approved content unchanged to the running local InfiniteCanvas app as Prompt Iteration nodes. Keep prompt generation in the producing skill; this skill only discovers targets and performs writes.

## Always use prompt scenes

- Route every skill write through the prompt-scene workflow. Never call the generic `/v1/nodes` text endpoint and never create a traditional text node.
- For one new prompt, create one scene-bound Prompt Iteration node titled `S1`. For several new prompts, create `S1`, `S2`, and so on in prompt order.
- Read [references/prompt-scenes-api.md](references/prompt-scenes-api.md) before every write or query.

## Recover scene bindings

Never rely on chat memory, node order, canvas coordinates, or a remembered node ID.

1. If `promptSetId` is unknown after a new conversation, run `ListPromptSets`:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action ListPromptSets
```

2. Match the user's project using the returned title, Canvas project name, scene count, and `promptSetId`. If more than one result is plausible, ask the user which one to use.
3. Before creating or updating scenes, query the exact bindings:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action GetSceneBindings `
  -PromptSetId 'commercial-001'
```

4. Treat `promptSetId + sceneKey` as the durable identity. Convert user-facing references consistently: `S2` maps to binding key `S02`, and `S5` maps to `S05`. Display node titles without zero padding (`S1`, `S2`, ...), but never infer identity from the title, visual position, or array order.

## Create missing prompt scenes

Write one UTF-8 manifest containing the stable prompt-set identity and every finished English/Chinese pair. Then run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateMissingScenes `
  -ManifestPath 'D:\path\prompt-scenes.json'
```

Use `S01`, `S02`, and other zero-padded stable scene keys. Set each manifest scene title to the matching compact display name: `S01` must use title `S1`, `S02` must use `S2`, and so on. For four prompts, create four nodes titled exactly `S1`, `S2`, `S3`, and `S4` in prompt order. The management script also normalizes these titles before sending so different AI tools cannot invent descriptive node names. Reuse the same `promptSetId` when continuing with S06-S10; their node titles are `S6` through `S10`. The operation creates only absent scene keys; it never overwrites existing scenes. Each new node starts with `v1`.

After the call, report `createdCount`, `existingCount`, and the returned scene-to-node bindings. Query the prompt set again if the response is ambiguous or incomplete.

## Append a version to one scene

Query bindings immediately before writing. Use the target binding's `versionCount` as the expected count:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action AppendVersion `
  -PromptSetId 'commercial-001' `
  -SceneKey 'S02' `
  -Path 'D:\path\scene-02-en.txt' `
  -InformationPath 'D:\path\scene-02-zh.txt' `
  -ExpectedVersionCount 1 `
  -Source 'codex' `
  -RequestId 'stable-unique-request-id'
```

For several revisions such as S02 and S05, query once, then send a separate append request to each stable scene key with a different request ID and that scene's own expected count. Do not batch them into one ambiguous text node.

If the API returns HTTP 409, stop. Query bindings again and explain whether the target changed, the request ID was reused, or another writer added a version. Do not bypass the conflict by silently changing the request ID.

After successful writes, query again and verify the returned `nodeId`, `latestVersion`, and `versionCount` for every requested scene.

## Content and safety rules

- Preserve the submitted body and Information string-for-string; add no headings, fences, translations, or formatting.
- Create only Prompt Iteration nodes through the scene API, even when the user sends a single prompt or calls the content ordinary text.
- Name newly created scene nodes only with the compact scene reference `S<n>` derived from `sceneKey`; never use a prompt summary or generated description as the node title.
- For MiniMax H3, write the complete executable English prompt to `text` and the complete matching Chinese explanation to `information` in the same version.
- Use a stable request ID for retries of the same write. Never retry an uncertain write with a new ID.
- Create temporary UTF-8 files with a filesystem editing tool. Delete only those exact temporary files after a confirmed successful send.
- Keep command-line titles ASCII; put multilingual scene titles in the UTF-8 manifest or reuse the persisted scene title.
- Use `source: codex` for Codex output and `source: reasonix` for Reasonix output unless the user specifies another source.
- The scripts read `%LOCALAPPDATA%\InfiniteCanvas\api.json` and authenticate locally. Never expose its token.
- If the app is not running or the API is unavailable, tell the user to start the updated InfiniteCanvas build and retry.
