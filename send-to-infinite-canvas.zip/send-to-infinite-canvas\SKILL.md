---
name: send-to-infinite-canvas
description: Send finished text unchanged to the user's local InfiniteCanvas app exclusively as scene-bound Prompt Iteration nodes, with paired English prompt text and Chinese Information preserved through strict UTF-8 file input, UTF-8 byte transport, and exact write verification. Query and recover prompt-set bindings after a new conversation, create only missing scenes, and append a new version to an exact scene such as S2 or S5 with idempotency and version-conflict protection. Use when the user asks to send, push, add, place, save, continue, or update generated prompts or text in InfiniteCanvas. Do not create generic text nodes, and do not generate, rewrite, translate, review, optimize, or bulk-rename either field.
---

# Send to InfiniteCanvas

Send user-approved content unchanged to the running local InfiniteCanvas app as Prompt Iteration nodes. Keep prompt generation in the producing skill; this skill only discovers targets and performs writes.

## Always use prompt scenes

- Route every skill write through the prompt-scene workflow. Never call the generic `/v1/nodes` text endpoint and never create a traditional text node.
- For one new prompt, create one scene-bound Prompt Iteration node whose default title is `S1`. For several new prompts, default to `S1`, `S2`, and so on in prompt order. Preserve an explicitly supplied UTF-8 title such as `轮回 S1`.
- Read [references/prompt-scenes-api.md](references/prompt-scenes-api.md) before every write or query.

## Recover scene bindings

Never rely on chat memory, node order, canvas coordinates, or a remembered node ID.

1. If `promptSetId` is unknown after a new conversation, run `ListPromptSets`:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action ListPromptSets
```

   If the user explicitly refers to the currently open Canvas, add `-ActiveCanvas`. The running app resolves that request from its active Canvas state, so the result excludes prompt sets saved in other Canvas projects:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action ListPromptSets -ActiveCanvas
```

2. Match the user's project using the returned title, Canvas project name, scene count, and `promptSetId`. If more than one result is plausible, ask the user which one to use.
3. Before creating or updating scenes, query the exact bindings:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action GetSceneBindings `
  -PromptSetId 'commercial-001'
```

4. Treat `promptSetId + sceneKey` as the only durable identity. Convert user-facing references consistently: `S2` maps to binding key `S02`, and `S5` maps to `S05`. Never infer identity from a visible title, title prefix, visual position, or array order, and never rename nodes by a title regex across a Canvas.

## Create missing prompt scenes

Write one UTF-8 manifest containing the stable prompt-set identity and every finished English/Chinese pair. Then run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateMissingScenes `
  -ManifestPath 'D:\path\prompt-scenes.json'
```

Use `S01`, `S02`, and other zero-padded stable scene keys. When `title` is omitted or blank, the script derives the compact default `S1`, `S2`, and so on. When the UTF-8 manifest explicitly supplies a title such as `轮回 S1`, preserve it exactly; do not normalize, prefix, translate, or copy it to other prompt sets. Reuse the same `promptSetId` when continuing an existing set. The operation creates only absent scene keys; it never overwrites existing scenes. Each new node starts with `v1`.

The script compares every newly persisted title, prompt, and Information field against the submitted manifest with ordinal string equality. Any mismatch is a failed write: stop, keep the same request ID, and do not retry with a new one. After the call, report `createdCount`, `existingCount`, and the returned scene-to-node bindings. Query the prompt set again if the response is ambiguous or incomplete.

## Append a version to one scene

Query bindings immediately before writing. Use the target binding's `versionCount` as the expected count:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action AppendVersion `
  -PromptSetId 'commercial-001' `
  -SceneKey 'S02' `
  -Path 'D:\path\scene-02-en.txt' `
  -InformationPath 'D:\path\scene-02-zh.txt' `
  -ExpectedVersionCount 1 `
  -Source 'codex' `
  -RequestId 'stable-unique-request-id'
```

For several revisions such as S02 and S05, query once, then send a separate append request to each stable scene key with a different request ID and that scene's own expected count. Do not batch them into one ambiguous text node.

If the API returns HTTP 409, stop. Query bindings again and explain whether the target changed, the request ID was reused, or another writer added a version. Do not bypass the conflict by silently changing the request ID.

`AppendVersion` accepts prompt and Information content only through `-Path` and `-InformationPath`. If an explicit multilingual title is needed, put it in a UTF-8 file and pass `-TitlePath`; do not place Chinese text inline on the command line. The script sends exact UTF-8 bytes, decodes response bytes explicitly as UTF-8, and rejects the response unless the persisted prompt, Information, and optional title match exactly.

After successful writes, query again and verify the returned `nodeId`, `latestVersion`, and `versionCount` for every requested scene.

## Content and safety rules

- Preserve the submitted body and Information string-for-string; add no headings, fences, translations, or formatting.
- Create only Prompt Iteration nodes through the scene API, even when the user sends a single prompt or calls the content ordinary text.
- Default newly created scene titles to the compact scene reference `S<n>` derived from `sceneKey`. Preserve only an explicit title from the UTF-8 manifest; never invent a prompt summary or descriptive node name.
- For MiniMax H3, write the complete executable English prompt to `text` and the complete matching Chinese explanation to `information` in the same version.
- Use a stable request ID for retries of the same write. Never retry an uncertain write with a new ID.
- Create prompt, Information, title, and manifest inputs as UTF-8 files with a filesystem editing tool. Delete only those exact temporary files after a confirmed successful send.
- Never use `Invoke-RestMethod`, shell-default encoding, inline Chinese command arguments, or an ad-hoc database edit for Skill writes. Use `scripts/manage-prompt-scenes.ps1`, which performs strict UTF-8 byte transport and exact post-write verification.
- If verification reports a mismatch, treat the write as uncertain. Do not alter or regenerate the source text, do not switch encodings, and do not retry with a new request ID.
- Use `source: codex` for Codex output and `source: reasonix` for Reasonix output unless the user specifies another source.
- The scripts read `%LOCALAPPDATA%\InfiniteCanvas\api.json` and authenticate locally. Never expose its token.
- If the app is not running or the API is unavailable, tell the user to start the updated InfiniteCanvas build and retry.
