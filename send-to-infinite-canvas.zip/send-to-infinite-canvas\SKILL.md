---
name: send-to-infinite-canvas
description: Send finished prompt text or other completed text unchanged into the user's local InfiniteCanvas app as a new text node. Use when the user asks to send, push, add, place, or save a generated prompt or text to InfiniteCanvas, the infinite canvas, or the local canvas app. Do not use this skill to generate, rewrite, translate, review, or optimize the text itself.
---

# Send to InfiniteCanvas

Send user-approved text unchanged to the running local InfiniteCanvas app. Treat the text node as a generic workflow node; prompts are only the initial use case.

## Workflow

1. Finish any separate generation or revision workflow first.
2. Identify the exact final text the user wants sent. Do not alter it during this skill.
3. For non-ASCII or multiline text, write the exact content to a temporary UTF-8 file and run the script with `-Path`. Use `-Text` only for short ASCII content; Windows PowerShell may corrupt non-ASCII command arguments before the script receives them.
4. Use a stable `-RequestId` when retrying the same send. The app uses it to prevent duplicate nodes.
5. Report the returned node ID and whether a new node was created.

## Send text

Use PowerShell:

```powershell
& '<skill-dir>\scripts\send-to-infinite-canvas.ps1' `
  -Text $finalText `
  -Title '镜头提示词' `
  -Source 'codex' `
  -RequestId 'codex-unique-request-id'
```

For Chinese, other non-ASCII content, or long/multiline text, use `-Path` instead of `-Text`. Omit `-Title` to use the safe default `From Codex`:

```powershell
& '<skill-dir>\scripts\send-to-infinite-canvas.ps1' `
  -Path 'D:\path\prompt.txt' `
  -Source 'reasonix'
```

The script reads `%LOCALAPPDATA%\InfiniteCanvas\api.json`, authenticates to the current localhost API, and returns JSON. If the app is not running or the config is stale, tell the user to start InfiniteCanvas and retry. Never expose the token in chat output.

## Constraints

- Preserve the submitted text byte-for-byte at the string level; do not add headings, fences, explanations, or formatting.
- Create temporary UTF-8 input files with a filesystem editing tool, not by embedding non-ASCII text in a PowerShell command. Delete only that exact temporary file after a successful send.
- Keep `-Title` ASCII when calling from Windows PowerShell; put the exact multilingual content in the UTF-8 input file.
- Default to `kind: text`. Other node kinds are reserved for later app capabilities.
- Use `source: codex` for Codex output and `source: reasonix` for Reasonix output unless the user specifies another source.
- Never send drafts unless the user explicitly asks to send a draft.
- Do not retry without the same `RequestId`; otherwise a network ambiguity may create a duplicate node.
