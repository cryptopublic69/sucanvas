---
name: send-to-infinite-canvas
description: Send finished text unchanged to the user's local InfiniteCanvas app, either as a generic text node or as scene-bound prompt-version nodes with paired English prompt text and Chinese Information. Query and recover prompt-set bindings after a new conversation, create only missing scenes, and append a new version to an exact scene such as S02 or S05 with idempotency and version-conflict protection. Use when the user asks to send, push, add, place, save, continue, or update generated prompts or text in InfiniteCanvas. Do not generate, rewrite, translate, review, or optimize either field.
---

# Send to InfiniteCanvas

Send user-approved content unchanged to the running local InfiniteCanvas app. Keep prompt generation in the producing skill; this skill only discovers targets and performs writes.

## Choose the operation

- Use the generic text-node workflow when the user wants an independent text node without scene/version identity.
- Use the prompt-scene workflow when prompts belong to numbered scenes, must enter prompt-version nodes, or must later update a specific scene.
- Read [references/prompt-scenes-api.md](references/prompt-scenes-api.md) before using any prompt-scene operation.

## Generic text node

Run:

```powershell
& '<skill-dir>\scripts\send-to-infinite-canvas.ps1' `
  -Path 'D:\path\prompt.txt' `
  -InformationPath 'D:\path\prompt-zh.txt' `
  -Title 'Scene prompt' `
  -Source 'codex' `
  -RequestId 'stable-unique-request-id'
```

Use `-Text` and `-Information` only for short ASCII content. For Chinese, other non-ASCII text, or multiline content, write exact UTF-8 files and use `-Path` and `-InformationPath`.

## Recover scene bindings

Never rely on chat memory, node order, canvas coordinates, or a remembered node ID.

1. If `promptSetId` is unknown after a new conversation, run `ListPromptSets`:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' -Action ListPromptSets
```

2. Match the user's project using the returned title, Canvas project name, scene count, and `promptSetId`. If more than one result is plausible, ask the user which one to use.
3. Before creating or updating scenes, query the exact bindings:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action GetSceneBindings `
  -PromptSetId 'commercial-001'
```

4. Treat `promptSetId + sceneKey` as the durable identity. Convert user references consistently: scene 2 is `S02`, scene 5 is `S05`. Do not infer identity from visual position or array order.

## Create missing prompt scenes

Write one UTF-8 manifest containing the stable prompt-set identity and every finished English/Chinese pair. Then run:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action CreateMissingScenes `
  -ManifestPath 'D:\path\prompt-scenes.json'
```

Use `S01`, `S02`, and other zero-padded stable scene keys. Reuse the same `promptSetId` when continuing with S06-S10. The operation creates only absent scene keys; it never overwrites existing scenes. Each new node starts with `v1`.

After the call, report `createdCount`, `existingCount`, and the returned scene-to-node bindings. Query the prompt set again if the response is ambiguous or incomplete.

## Append a version to one scene

Query bindings immediately before writing. Use the target binding's `versionCount` as the expected count:

```powershell
& '<skill-dir>\scripts\manage-prompt-scenes.ps1' `
  -Action AppendVersion `
  -PromptSetId 'commercial-001' `
  -SceneKey 'S02' `
  -Path 'D:\path\scene-02-en.txt' `
  -InformationPath 'D:\path\scene-02-zh.txt' `
  -ExpectedVersionCount 1 `
  -Source 'codex' `
  -RequestId 'stable-unique-request-id'
```

For several revisions such as S02 and S05, query once, then send a separate append request to each stable scene key with a different request ID and that scene's own expected count. Do not batch them into one ambiguous text node.

If the API returns HTTP 409, stop. Query bindings again and explain whether the target changed, the request ID was reused, or another writer added a version. Do not bypass the conflict by silently changing the request ID.

After successful writes, query again and verify the returned `nodeId`, `latestVersion`, and `versionCount` for every requested scene.

## Content and safety rules

- Preserve the submitted body and Information string-for-string; add no headings, fences, translations, or formatting.
- For MiniMax H3, write the complete executable English prompt to `text` and the complete matching Chinese explanation to `information` in the same version.
- Use a stable request ID for retries of the same write. Never retry an uncertain write with a new ID.
- Create temporary UTF-8 files with a filesystem editing tool. Delete only those exact temporary files after a confirmed successful send.
- Keep command-line titles ASCII; put multilingual scene titles in the UTF-8 manifest or reuse the persisted scene title.
- Use `source: codex` for Codex output and `source: reasonix` for Reasonix output unless the user specifies another source.
- The scripts read `%LOCALAPPDATA%\InfiniteCanvas\api.json` and authenticate locally. Never expose its token.
- If the app is not running or the API is unavailable, tell the user to start the updated InfiniteCanvas build and retry.
