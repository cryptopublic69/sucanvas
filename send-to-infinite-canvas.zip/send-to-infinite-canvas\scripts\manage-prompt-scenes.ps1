[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('ListPromptSets', 'GetSceneBindings', 'CreateMissingScenes', 'AppendVersion')]
    [string]$Action,

    [string]$PromptSetId,
    [string]$SceneKey,
    [string]$ManifestPath,
    [AllowEmptyString()]
    [string]$Text,
    [string]$Path,
    [AllowEmptyString()]
    [string]$Information,
    [string]$InformationPath,
    [string]$Title,
    [string]$Source = 'codex',
    [string]$RequestId,
    [int]$ExpectedVersionCount = -1,
    [string]$ApiConfigPath
)

function ConvertTo-JsonString {
    param([AllowEmptyString()][string]$Value)

    $builder = [System.Text.StringBuilder]::new($Value.Length + 16)
    foreach ($character in $Value.ToCharArray()) {
        $code = [int]$character
        if ($code -eq 8) { [void]$builder.Append('\b') }
        elseif ($code -eq 9) { [void]$builder.Append('\t') }
        elseif ($code -eq 10) { [void]$builder.Append('\n') }
        elseif ($code -eq 12) { [void]$builder.Append('\f') }
        elseif ($code -eq 13) { [void]$builder.Append('\r') }
        elseif ($code -eq 34) { [void]$builder.Append('\"') }
        elseif ($code -eq 92) { [void]$builder.Append('\\') }
        elseif ($code -lt 32) { [void]$builder.AppendFormat('\u{0:x4}', $code) }
        else { [void]$builder.Append($character) }
    }
    $builder.ToString()
}

function Read-Utf8Text {
    param(
        [string]$InlineValue,
        [string]$FilePath,
        [string]$Label,
        [switch]$Required
    )

    if (-not [string]::IsNullOrEmpty($InlineValue) -and -not [string]::IsNullOrEmpty($FilePath)) {
        throw "Use either the inline $Label value or its path, not both."
    }
    if (-not [string]::IsNullOrEmpty($FilePath)) {
        $resolvedPath = (Resolve-Path -LiteralPath $FilePath -ErrorAction Stop).Path
        return Get-Content -LiteralPath $resolvedPath -Raw -Encoding UTF8
    }
    if ($Required -and [string]::IsNullOrEmpty($InlineValue)) {
        throw "$Label is required."
    }
    return [string]$InlineValue
}

function Require-Value {
    param([string]$Value, [string]$Label)
    if ([string]::IsNullOrWhiteSpace($Value)) {
        throw "$Label is required for action $Action."
    }
}

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$configPath = if ([string]::IsNullOrWhiteSpace($ApiConfigPath)) {
    $localAppData = [Environment]::GetFolderPath('LocalApplicationData')
    Join-Path $localAppData 'InfiniteCanvas\api.json'
}
else {
    $ApiConfigPath
}
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "InfiniteCanvas API config was not found. Start InfiniteCanvas, then retry. Expected: $configPath"
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace([string]$config.baseUrl) -or [string]::IsNullOrWhiteSpace([string]$config.token)) {
    throw 'InfiniteCanvas API config is invalid. Restart InfiniteCanvas, then retry.'
}
$headers = @{ Authorization = "Bearer $($config.token)" }

try {
    if ($Action -eq 'ListPromptSets') {
        $response = Invoke-RestMethod `
            -Method Get `
            -Uri "$($config.baseUrl)/v1/prompt-sets" `
            -Headers $headers `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'GetSceneBindings') {
        Require-Value $PromptSetId 'PromptSetId'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $response = Invoke-RestMethod `
            -Method Get `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes" `
            -Headers $headers `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'CreateMissingScenes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $body = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8
        $manifest = $body | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.promptSetId)) {
            throw 'The UTF-8 manifest must contain promptSetId.'
        }
        foreach ($scene in @($manifest.scenes)) {
            $sceneKey = [string]$scene.sceneKey
            $sceneMatch = [regex]::Match($sceneKey, '^S0*([1-9][0-9]*)$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $sceneMatch.Success) {
                throw "Scene key '$sceneKey' is invalid. Use S01, S02, and other positive S-number keys."
            }
            $displayTitle = 'S' + ([int]$sceneMatch.Groups[1].Value)
            if ($null -eq $scene.PSObject.Properties['title']) {
                $scene | Add-Member -NotePropertyName title -NotePropertyValue $displayTitle
            }
            else {
                $scene.title = $displayTitle
            }
        }
        $body = $manifest | ConvertTo-Json -Depth 32
        $encodedPromptSetId = [Uri]::EscapeDataString([string]$manifest.promptSetId)
        $response = Invoke-RestMethod `
            -Method Post `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes:create-missing" `
            -Headers $headers `
            -ContentType 'application/json; charset=utf-8' `
            -Body $body `
            -TimeoutSec 30
    }
    else {
        Require-Value $PromptSetId 'PromptSetId'
        Require-Value $SceneKey 'SceneKey'
        Require-Value $RequestId 'RequestId'
        $finalText = Read-Utf8Text -InlineValue $Text -FilePath $Path -Label 'Text' -Required
        $finalInformation = Read-Utf8Text -InlineValue $Information -FilePath $InformationPath -Label 'Information'
        $json = '{"text":"' + (ConvertTo-JsonString $finalText) +
            '","information":"' + (ConvertTo-JsonString $finalInformation) +
            '","source":"' + (ConvertTo-JsonString $Source) +
            '","requestId":"' + (ConvertTo-JsonString $RequestId) + '"'
        if (-not [string]::IsNullOrWhiteSpace($Title)) {
            $json += ',"title":"' + (ConvertTo-JsonString $Title) + '"'
        }
        if ($ExpectedVersionCount -ge 0) {
            $json += ',"expectedVersionCount":' + $ExpectedVersionCount
        }
        $json += '}'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $encodedSceneKey = [Uri]::EscapeDataString($SceneKey)
        $response = Invoke-RestMethod `
            -Method Post `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes/$encodedSceneKey/versions:append" `
            -Headers $headers `
            -ContentType 'application/json; charset=utf-8' `
            -Body $json `
            -TimeoutSec 30
    }
}
catch {
    $details = $_.ErrorDetails.Message
    if ([string]::IsNullOrWhiteSpace($details)) {
        $details = $_.Exception.Message
    }
    throw "InfiniteCanvas prompt scene request failed. Make sure the app is running and the target binding is current. $details"
}

$response | ConvertTo-Json -Depth 32
