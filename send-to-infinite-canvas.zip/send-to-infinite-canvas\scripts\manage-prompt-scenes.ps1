[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('ListPromptSets', 'GetSceneBindings', 'CreateMissingScenes', 'AppendVersion')]
    [string]$Action,

    [switch]$ActiveCanvas,
    [string]$PromptSetId,
    [string]$SceneKey,
    [string]$ManifestPath,
    [AllowEmptyString()]
    [string]$Text,
    [string]$Path,
    [AllowEmptyString()]
    [string]$Information,
    [string]$InformationPath,
    [string]$Title,
    [string]$TitlePath,
    [string]$Source = 'codex',
    [string]$RequestId,
    [int]$ExpectedVersionCount = -1,
    [string]$ApiConfigPath
)

function ConvertTo-JsonString {
    param([AllowEmptyString()][string]$Value)

    $builder = [System.Text.StringBuilder]::new($Value.Length + 16)
    foreach ($character in $Value.ToCharArray()) {
        $code = [int]$character
        if ($code -eq 8) { [void]$builder.Append('\b') }
        elseif ($code -eq 9) { [void]$builder.Append('\t') }
        elseif ($code -eq 10) { [void]$builder.Append('\n') }
        elseif ($code -eq 12) { [void]$builder.Append('\f') }
        elseif ($code -eq 13) { [void]$builder.Append('\r') }
        elseif ($code -eq 34) { [void]$builder.Append('\"') }
        elseif ($code -eq 92) { [void]$builder.Append('\\') }
        elseif ($code -lt 32) { [void]$builder.AppendFormat('\u{0:x4}', $code) }
        else { [void]$builder.Append($character) }
    }
    $builder.ToString()
}

function Read-Utf8Text {
    param(
        [string]$InlineValue,
        [string]$FilePath,
        [string]$Label,
        [switch]$Required
    )

    if (-not [string]::IsNullOrEmpty($InlineValue) -and -not [string]::IsNullOrEmpty($FilePath)) {
        throw "Use either the inline $Label value or its path, not both."
    }
    if (-not [string]::IsNullOrEmpty($FilePath)) {
        $resolvedPath = (Resolve-Path -LiteralPath $FilePath -ErrorAction Stop).Path
        return Get-Content -LiteralPath $resolvedPath -Raw -Encoding UTF8
    }
    if ($Required -and [string]::IsNullOrEmpty($InlineValue)) {
        throw "$Label is required."
    }
    return [string]$InlineValue
}

function Require-Value {
    param([string]$Value, [string]$Label)
    if ([string]::IsNullOrWhiteSpace($Value)) {
        throw "$Label is required for action $Action."
    }
}

function Assert-ExactText {
    param(
        [AllowNull()][object]$Actual,
        [AllowEmptyString()][string]$Expected,
        [string]$Label
    )

    $actualText = if ($null -eq $Actual) { $null } else { [string]$Actual }
    if ($null -eq $actualText -or -not [string]::Equals($actualText, $Expected, [System.StringComparison]::Ordinal)) {
        throw "UTF-8 round-trip verification failed for $Label. The response did not exactly match the submitted text. Do not retry with a new RequestId."
    }
}

function Invoke-Utf8JsonRequest {
    param(
        [ValidateSet('GET', 'POST')]
        [string]$Method,
        [string]$Uri,
        [AllowNull()][string]$Body,
        [int]$TimeoutSec
    )

    $request = [System.Net.HttpWebRequest]::Create($Uri)
    $request.Method = $Method
    $request.Accept = 'application/json'
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = $TimeoutSec * 1000
    $request.Headers[[System.Net.HttpRequestHeader]::Authorization] = "Bearer $($config.token)"

    if ($Method -eq 'POST') {
        $request.ContentType = 'application/json; charset=utf-8'
        $requestBytes = $script:StrictUtf8.GetBytes([string]$Body)
        $request.ContentLength = $requestBytes.Length
        $requestStream = $request.GetRequestStream()
        try {
            $requestStream.Write($requestBytes, 0, $requestBytes.Length)
        }
        finally {
            $requestStream.Dispose()
        }
    }

    $webResponse = $null
    try {
        $webResponse = $request.GetResponse()
    }
    catch [System.Net.WebException] {
        $errorResponse = $_.Exception.Response
        if ($null -eq $errorResponse) {
            throw
        }
        try {
            $errorStream = $errorResponse.GetResponseStream()
            $errorMemory = [System.IO.MemoryStream]::new()
            try {
                $errorStream.CopyTo($errorMemory)
                $errorText = $script:StrictUtf8.GetString($errorMemory.ToArray())
            }
            finally {
                $errorMemory.Dispose()
                $errorStream.Dispose()
            }
            throw "HTTP $([int]$errorResponse.StatusCode): $errorText"
        }
        finally {
            $errorResponse.Dispose()
        }
    }

    try {
        $responseStream = $webResponse.GetResponseStream()
        $responseMemory = [System.IO.MemoryStream]::new()
        try {
            $responseStream.CopyTo($responseMemory)
            $responseText = $script:StrictUtf8.GetString($responseMemory.ToArray())
        }
        finally {
            $responseMemory.Dispose()
            $responseStream.Dispose()
        }
    }
    finally {
        $webResponse.Dispose()
    }

    if ([string]::IsNullOrWhiteSpace($responseText)) {
        return $null
    }
    return $responseText | ConvertFrom-Json
}

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$script:StrictUtf8 = [System.Text.UTF8Encoding]::new($false, $true)

$configPath = if ([string]::IsNullOrWhiteSpace($ApiConfigPath)) {
    $localAppData = [Environment]::GetFolderPath('LocalApplicationData')
    Join-Path $localAppData 'InfiniteCanvas\api.json'
}
else {
    $ApiConfigPath
}
if (-not (Test-Path -LiteralPath $configPath -PathType Leaf)) {
    throw "InfiniteCanvas API config was not found. Start InfiniteCanvas, then retry. Expected: $configPath"
}
$config = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ([string]::IsNullOrWhiteSpace([string]$config.baseUrl) -or [string]::IsNullOrWhiteSpace([string]$config.token)) {
    throw 'InfiniteCanvas API config is invalid. Restart InfiniteCanvas, then retry.'
}
try {
    if ($Action -eq 'ListPromptSets') {
        $query = if ($ActiveCanvas) { '?activeCanvasOnly=true' } else { '' }
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/prompt-sets$query" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'GetSceneBindings') {
        Require-Value $PromptSetId 'PromptSetId'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $response = Invoke-Utf8JsonRequest `
            -Method GET `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes" `
            -TimeoutSec 10
    }
    elseif ($Action -eq 'CreateMissingScenes') {
        Require-Value $ManifestPath 'ManifestPath'
        $resolvedManifestPath = (Resolve-Path -LiteralPath $ManifestPath -ErrorAction Stop).Path
        $body = Get-Content -LiteralPath $resolvedManifestPath -Raw -Encoding UTF8
        $manifest = $body | ConvertFrom-Json
        if ([string]::IsNullOrWhiteSpace([string]$manifest.promptSetId)) {
            throw 'The UTF-8 manifest must contain promptSetId.'
        }
        foreach ($scene in @($manifest.scenes)) {
            $sceneKey = [string]$scene.sceneKey
            $sceneMatch = [regex]::Match($sceneKey, '^S0*([1-9][0-9]*)$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $sceneMatch.Success) {
                throw "Scene key '$sceneKey' is invalid. Use S01, S02, and other positive S-number keys."
            }
            $displayTitle = 'S' + ([int]$sceneMatch.Groups[1].Value)
            if ($null -eq $scene.PSObject.Properties['title']) {
                $scene | Add-Member -NotePropertyName title -NotePropertyValue $displayTitle
            }
            elseif ([string]::IsNullOrWhiteSpace([string]$scene.title)) {
                $scene.title = $displayTitle
            }
        }
        $body = $manifest | ConvertTo-Json -Depth 32
        $encodedPromptSetId = [Uri]::EscapeDataString([string]$manifest.promptSetId)
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes:create-missing" `
            -Body $body `
            -TimeoutSec 30

        $expectedScenes = @{}
        foreach ($scene in @($manifest.scenes)) {
            $expectedScenes[[string]$scene.sceneKey] = $scene
        }
        foreach ($mutation in @($response.scenes)) {
            if (-not [bool]$mutation.created) {
                continue
            }
            $actualSceneKey = [string]$mutation.binding.sceneKey
            if (-not $expectedScenes.ContainsKey($actualSceneKey)) {
                throw "UTF-8 round-trip verification failed: response contained unexpected scene '$actualSceneKey'."
            }
            $expectedScene = $expectedScenes[$actualSceneKey]
            Assert-ExactText $mutation.binding.sceneTitle ([string]$expectedScene.title) "$actualSceneKey binding title"
            Assert-ExactText $mutation.node.title ([string]$expectedScene.title) "$actualSceneKey node title"
            Assert-ExactText $mutation.node.content.sceneTitle ([string]$expectedScene.title) "$actualSceneKey content title"
            Assert-ExactText $mutation.node.content.text ([string]$expectedScene.text) "$actualSceneKey text"
            Assert-ExactText $mutation.node.content.information ([string]$expectedScene.information) "$actualSceneKey Information"
            $activeVersionId = [string]$mutation.node.content.activePromptVersionId
            $activeVersion = @($mutation.node.content.promptVersions) | Where-Object { [string]$_.id -eq $activeVersionId } | Select-Object -First 1
            if ($null -eq $activeVersion) {
                throw "UTF-8 round-trip verification failed: $actualSceneKey has no matching active version."
            }
            Assert-ExactText $activeVersion.title ([string]$expectedScene.title) "$actualSceneKey version title"
            Assert-ExactText $activeVersion.text ([string]$expectedScene.text) "$actualSceneKey version text"
            Assert-ExactText $activeVersion.information ([string]$expectedScene.information) "$actualSceneKey version Information"
        }
    }
    else {
        Require-Value $PromptSetId 'PromptSetId'
        Require-Value $SceneKey 'SceneKey'
        Require-Value $RequestId 'RequestId'
        Require-Value $Path 'Path (UTF-8 prompt file)'
        Require-Value $InformationPath 'InformationPath (UTF-8 Information file)'
        if (-not [string]::IsNullOrEmpty($Text) -or -not [string]::IsNullOrEmpty($Information)) {
            throw 'AppendVersion accepts prompt text and Information only through -Path and -InformationPath UTF-8 files.'
        }
        if (-not [string]::IsNullOrEmpty($Title) -and [string]::IsNullOrEmpty($TitlePath)) {
            throw 'Pass an explicit title through -TitlePath as a UTF-8 file.'
        }
        $finalText = Read-Utf8Text -FilePath $Path -Label 'Text' -Required
        $finalInformation = Read-Utf8Text -FilePath $InformationPath -Label 'Information'
        $finalTitle = Read-Utf8Text -InlineValue $Title -FilePath $TitlePath -Label 'Title'
        if (-not [string]::IsNullOrEmpty($finalTitle)) {
            $finalTitle = $finalTitle.TrimEnd([char[]]"`r`n")
        }
        $json = '{"text":"' + (ConvertTo-JsonString $finalText) +
            '","information":"' + (ConvertTo-JsonString $finalInformation) +
            '","source":"' + (ConvertTo-JsonString $Source) +
            '","requestId":"' + (ConvertTo-JsonString $RequestId) + '"'
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            $json += ',"title":"' + (ConvertTo-JsonString $finalTitle) + '"'
        }
        if ($ExpectedVersionCount -ge 0) {
            $json += ',"expectedVersionCount":' + $ExpectedVersionCount
        }
        $json += '}'
        $encodedPromptSetId = [Uri]::EscapeDataString($PromptSetId)
        $encodedSceneKey = [Uri]::EscapeDataString($SceneKey)
        $response = Invoke-Utf8JsonRequest `
            -Method POST `
            -Uri "$($config.baseUrl)/v1/prompt-sets/$encodedPromptSetId/scenes/$encodedSceneKey/versions:append" `
            -Body $json `
            -TimeoutSec 30

        Assert-ExactText $response.version.text $finalText "$SceneKey version text"
        Assert-ExactText $response.version.information $finalInformation "$SceneKey version Information"
        if (-not [string]::IsNullOrWhiteSpace($finalTitle)) {
            Assert-ExactText $response.version.title $finalTitle "$SceneKey version title"
            Assert-ExactText $response.binding.sceneTitle $finalTitle "$SceneKey binding title"
            Assert-ExactText $response.node.title $finalTitle "$SceneKey node title"
        }
    }
}
catch {
    $details = $_.ErrorDetails.Message
    if ([string]::IsNullOrWhiteSpace($details)) {
        $details = $_.Exception.Message
    }
    throw "InfiniteCanvas prompt scene request failed. Make sure the app is running and the target binding is current. $details"
}

$response | ConvertTo-Json -Depth 32
