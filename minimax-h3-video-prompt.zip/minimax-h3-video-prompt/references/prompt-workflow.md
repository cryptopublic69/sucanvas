# H3 ComfyUI 提示词工作流

## 目录

1. 保留三类任务路由
2. 路由与输出格式映射
3. ComfyUI 素材编号与职责
4. 主体、任务与保留分析
5. 镜头时间轴
6. 台词、音色与声音
7. 视频编辑
8. 常见失败与修正
9. 中英双份交付与 InfiniteCanvas

## 1. 保留三类任务路由

进入 skill 后第一问仍只提供以下三项，不用“基础格式 / Full-Reference 格式”替代用户熟悉的路由：

- **文生视频**：没有任何参考素材。
- **图生视频**：存在参考图片，包括严格首帧、严格尾帧、严格首尾帧，或接入 `ref_image_N` 的人物/服装/场景/风格参考。
- **参考生视频**：使用图片、视频、视频伴音、独立音频中的多种参考，或编辑已有视频。

任务路由只由素材决定，和场景、内容、尺度、人物数量无关。用户中途改变素材方案时，重新判断路由。

## 2. 路由与输出格式映射

路由选定后，再根据 ComfyUI 实际输入选择官方格式：

| 用户路由 | ComfyUI 输入 | 输出格式 |
|---|---|---|
| 文生视频 | 只有 prompt | 基础三字段 |
| 图生视频 | `first_frame`、`last_frame` 或两者 | 官方图片对齐指令 + 基础三字段 |
| 图生视频 | 一个或多个 `ref_image_N` | Full-Reference 六段 |
| 参考生视频 | 任意 `ref_image_N` / `ref_video_N` / `ref_video_audio_N` / `ref_audio_N` 组合 | Full-Reference 六段 |
| 参考生视频 | `ref_video_N` 作为编辑源 | Full-Reference 六段，`summary` 使用 `video editing` |

基础三字段固定为：

1. `integrated_multimodal_description`
2. `overall_soundscape`
3. `non_diegetic_music`

Full-Reference 六段固定为：

1. `subject_definitions`
2. `summary`
3. `retention_analysis`
4. `detailed_description`
5. `overall_soundscape`
6. `non_diegetic_music`

最终提示词的字段说明统一用英文。仅 `<d>[Language] ...</d>` 中的对白/歌词和用户明确要求出现在画面里的文字保留原语言。不要再输出旧式 `【参考素材说明】`、`【核心创意】`、`【画面过程描述】`、`【声音设计】`、`【整体要求与限制】`，也不要使用 `@图片N/@视频N/@音频N`。

## 3. ComfyUI 素材编号与职责

### 3.1 输入到官方标签的映射

- `ref_image_N` → `<Picture N>`
- `ref_video_N` → `<Video N>`
- `ref_video_audio_N` → 与同编号 `<Video N>` 配对的视频伴音；它仍会占用一个全局 `<Audio j>` 编号，并排在对应 `<Video N>` 之前
- `ref_audio_N` → 独立参考音频；其 `<Audio j>` 编号接在所有已接入的视频伴音之后，不保证与输入后缀 `N` 相同
- 需要跨镜头稳定追踪的可见人物、物体或场景 → `<Subject N>`

ComfyUI 在内部按“图片 → 视频（每个已配对伴音先于对应视频）→ 独立音频”组装参考输入。`<Picture i>` 和 `<Video k>` 各自按类型编号；所有视频伴音与独立音频共同使用一套连续的 `<Audio j>` 编号。必须按节点实际出现顺序计算音频标签，不能把 `ref_video_audio_N` 与 `ref_audio_N` 当作两套音频编号。

### 3.2 职责边界

- 每份素材只绑定用户真正需要的维度，不笼统写“完全参考”。
- 同一素材可承担多个相容职责，但必须逐项写清。
- `<Picture N>` 可供人物身份、服装、场景、物体、构图或风格参考。
- `<Video N>` 可供动作、镜头、节奏、空间关系、原视频编辑或连续性参考。
- `<Audio N>` 可供原音频复用、部分复用、音乐/节奏参考或音色参考。
- 每个持续出现的角色都定义为稳定 `<Subject N>`；如需说话，按首次发声顺序绑定稳定 `(S1)`、`(S2)`。

## 4. 主体、任务与保留分析

### 4.1 `subject_definitions`

首次定义 `<Subject N>` 时用英文写清：它来自哪份 `<Picture N>` / `<Video N>`，可见身份特征、服装、年龄感、当前状态，以及声线参考如何绑定。不要凭空改写参考素材事实。

音色只参考时使用明确的防泄漏句式：

`<Audio 1> is the voice-timbre reference for <Subject 1> (S1). Only the vocal timbre, texture, speaking quality, and delivery character are referenced; the original signal, wording, phonemes, breaths, pauses, timing, and background sounds are not copied.`

### 4.2 `summary`

用英文写任务类型与一句创意概述。任务类型按目标选择：

- `keyframe completion`
- `reference generation`
- `video editing`
- `video continuation`
- `audio reuse`
- `audio reference`

`summary` 不放台词原文，不展开时间轴。

### 4.3 `retention_analysis`

逐素材写明参考强度与具体保留项。视觉素材使用：

- `fully_preserved`
- `partially_preserved`
- `attribute_transfer`
- `weak_reference`

音频素材使用：

- `fully_copy`
- `partially_copy`
- `reference`
- `weak_reference`

音色参考必须用 `reference`，并再次明确只参考音色和说话质感，不复制原内容、音素、呼吸、停顿、时序或底噪。不要用 `fully_copy` 或 `partially_copy` 描述仅音色迁移，否则容易把参考音频开头的含糊内容一起生成。

## 5. 镜头时间轴

### 5.1 标准写法

- 第一镜头写 `[Shot 1] ...`，不加时间戳。
- 后续切镜写 `[Shot N] At 00:SS.mmm, ...`，时间表示该镜头的准确切入点。
- 每镜头写清景别/构图、主体位置、可见动作、环境与光线、相机运动、对白、同步音效和转场。
- 默认硬切；只有用户明确需要才使用叠化、遮挡切、闪白等转场。
- 一镜到底只写 `[Shot 1]`，不得再出现 Shot 2、硬切或跳场。

### 5.2 连续性

- 保持人物身份、服装、道具、空间关系、屏幕方位和动作动力链连续。
- 严格首帧要从输入姿态立即自然启动，不重复静止展示。
- 严格尾帧要自然到达目标姿态、构图和状态。
- 严格首尾帧默认不切镜；描述首帧到尾帧之间的连续动力链、遮挡、位移、光线和材质变化。
- 跨镜头声音延续用 `<cutoff>` 与 `<scenetrans>`，不重复整句对白，也不写中文元注释。

## 6. 台词、音色与声音

### 6.1 对白格式

镜头先写 `<Subject N>` 的动作和口型，再紧接唯一说话人、发声方式与对白：

`<Subject 1> (S1) says in a warm, lightly smiling tone, <d>[Chinese] 最近很多小伙伴又回到了 ComfyUI 的怀抱。</d>`

规则：

- `(Sx)` 对同一说话人全片保持不变。
- `<d>` 内只放 `[Language]` 和准确发声文字，不放人物名、动作、语气或解释。
- 每句对白原文只在主描述所属镜头出现一次。
- `overall_soundscape` 和 `non_diegetic_music` 不得重复对白。
- 台词前后各预留约 0.3 秒自然缓冲；切镜不压在尾音帧。
- 中文口语约每秒 4–5 字，据此分配镜头时长。

### 6.2 零文字与字幕

默认把以下英文约束写成 `integrated_multimodal_description` 或 `detailed_description` 的第一句：

`The entire video contains no visible text of any kind, including subtitles, captions, titles, logos, watermarks, brand marks, signs, interface text, symbols, icons, stickers, or text-like graphics. No subtitles are rendered at any opacity; subtitle visibility is zero.`

不得在官方字段之前另加中文最高优先级区块。只有用户明确要求可见文字时才例外，并用双引号提供准确原文与位置；其余镜头仍保持无字。

### 6.3 声音字段

- `overall_soundscape`：用英文概括全片环境声、动作声、非语言人声、空间混响与同步关系。
- `non_diegetic_music`：写非叙事性配乐；不要背景音乐时准确写 `N/A`。
- 与画面动作强同步的声音可在对应 Shot 中写一次，再在 `overall_soundscape` 只概括总体层次，不逐字重复。
- 音频只作声线参考时，绝不把参考音频的原话、含糊开场声、呼吸、停顿或背景声写入声音字段。

亲热场景继续遵守 skill 主文件中的双方反应声与接吻声音自然化规则：双方呼吸/非语言反应按动作同步；接吻以低沉急促呼吸为唯一人体声，不强调水声、吧唧声或吮吸声。

## 7. 视频编辑

- 在 `subject_definitions` 中声明 `<Video N>` 是被编辑源，并定义要替换或新增的 `<Subject N>`。
- 在 `summary` 标注 `video editing`，一句话写清修改目标。
- 在 `retention_analysis` 中列出原视频需要保留的时间、镜头运动、背景、未编辑人物、声音或空间关系，以及允许修改的局部。
- `detailed_description` 描述目标对象如何继承原运动轨迹、接触、遮挡、尺度、透视、光线、阴影、反射和环境融合。
- 除指定修改外，保持原构图、时序、镜头运动与未编辑声音。

## 8. 常见失败与修正

| 失败写法 | 修正 |
|---|---|
| 路由直接改成“基础/六段格式” | 第一问仍保留文生 / 图生 / 参考生；格式在路由后决定 |
| 输出 `@图片1` 或旧式中文区块 | 改用官方字段与 `<Picture 1>` / `<Video 1>` / `<Audio 1>` 标签 |
| Full-Reference 缺少字段或顺序错误 | 严格按六段固定顺序输出 |
| 严格首尾帧误写为普通图片参考 | 使用官方对齐指令和基础三字段 |
| 参考图人物跨镜头漂移 | 抽象为稳定 `<Subject N>`，在定义与保留分析中锁定特征 |
| 音色参考产生开场胡话 | 把 `<Audio N>` 标为 `reference`，明确不复制原信号、文字、音素、呼吸、停顿和底噪 |
| 同一句台词在声音字段重复 | 台词只在所属 Shot 的 `<d>` 中出现一次 |
| 多人串词 | 每人固定 `<Subject N> (Sx)`，动作/口型后立即放所属 `<d>` |
| 第一镜头写 `At 00:00.000` | `[Shot 1]` 不加时间；仅后续切镜写准确时间 |
| 三秒镜头塞入长台词 | 缩短台词、延长镜头或用 `<cutoff>` / `<scenetrans>` 设计跨切 |
| 要音乐又写 `N/A` | 删除冲突，明确哪些段落有音乐 |
| 视频编辑只写替换目标 | 补充运动、遮挡、光影、环境融合与保持项 |

## 9. 中英双份交付与 InfiniteCanvas

每次完成提示词后生成两份内容：

- **English prompt**：唯一用于 ComfyUI H3 执行的完整提示词。保持官方三字段或六段结构、素材标签、Shot 时间轴、声音字段和英文限制；对白继续保留用户指定的原语言。
- **中文解释**：按相同字段顺序和 Shot 顺序完整解释英文提示词。逐项对应素材职责、主体、保留分析、动作、镜头、声音、时间点和限制，不省略关键约束，不添加英文成品中不存在的新设计。

独立审查时把两份内容一起提交，除格式、时间轴、声音和素材绑定外，额外核对中英对应关系。

用户要求发送到 InfiniteCanvas 时，在审查完成后调用 `send-to-infinite-canvas`。只把 English prompt 本体写入 `content.text`，只把中文解释本体写入 `content.information`；两份内容均原样发送，不包含聊天中的分区标题，不在发送阶段再次翻译或润色。
