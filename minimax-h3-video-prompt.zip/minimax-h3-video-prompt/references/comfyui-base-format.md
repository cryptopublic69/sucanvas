# ComfyUI 基础格式：T2VA / I2VA / FL2VA / L2VA

此格式用于 MiniMax H3 Image to Video 节点：纯文字，或使用 `first_frame`、`last_frame` 的严格关键帧任务。

## 固定三字段

按以下顺序输出，字段名不得翻译、改名、增删或调序：

```text
integrated_multimodal_description: ...

overall_soundscape: ...

non_diegetic_music: ...
```

- 所有字段说明使用英文。
- 对白/歌词写成 `<d>[Language] exact words.</d>`，可保留原语言。
- 说话人按首次发声顺序绑定稳定 `(S1)`、`(S2)`。
- `[Shot 1]` 不加时间戳；后续切镜写 `[Shot N] At 00:SS.mmm, ...`。
- 无背景音乐时准确写 `non_diegetic_music: N/A`。

## T2VA：文生视频

不加图片对齐指令，直接输出三字段：

```text
integrated_multimodal_description: [Shot 1] [English visual style, initial composition, subject, scene, action, camera, dialogue and synchronized diegetic sound.] [Shot 2] At 00:SS.mmm, ...

overall_soundscape: [English description of ambience, effects, nonverbal voices, spatial mix and dynamics. Do not repeat dialogue.]

non_diegetic_music: [English music description or N/A]
```

## I2VA：严格首帧

第一行必须逐字使用：

```text
For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.
```

空一行后输出三字段。`<Picture 1>` 是 0.00 秒的实际首帧。`[Shot 1]` 先锚定图片中的风格、人物、服装、构图、场景、物体和空间关系，再描述下一步动作如何立即自然启动。

## FL2VA：严格首尾帧

第一行必须使用官方句式，并把 `N` 换成实际最后一个镜头编号，把 `S.SS` 换成成片有效时长（严格两位小数）：

```text
How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.
```

空一行后输出三字段。Picture 1 是严格首帧，Picture 2 是严格尾帧。默认一镜到底时两者都属于 Shot 1；如用户明确要求多镜头，Picture 2 属于实际最后一个 Shot。主描述必须给出首帧到尾帧之间连续、可执行的动作动力链与相机/光线/遮挡变化。

## L2VA：严格尾帧

第一行必须使用官方句式，并把 `N` 和 `S.SS` 换成实际值：

```text
How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.
```

空一行后输出三字段。`<Picture 1>` 是最后一帧，而不是天然属于 Shot 1。根据用户意图推断合理的早期状态，描述人物、物体、相机和场景如何逐步到达尾帧中的姿态、构图、光线和状态。

## 默认零文字第一句

若用户没有明确要求可见文字，把下句放在 `integrated_multimodal_description:` 后、`[Shot 1]` 前，作为主描述第一句：

```text
The entire video contains no visible text of any kind, including subtitles, captions, titles, logos, watermarks, brand marks, signs, interface text, symbols, icons, stickers, or text-like graphics. No subtitles are rendered at any opacity; subtitle visibility is zero.
```

## 对白与跨切

标准对白：

```text
<Subject 1> (S1) says in a warm, lightly smiling tone, <d>[Chinese] 准确台词。</d>
```

基础格式没有 `subject_definitions` 时，先在 `[Shot 1]` 自然描述该人物的外观、服装和位置，再为其绑定 `(S1)`。同一句对白跨切时使用 `<cutoff>` 与 `<scenetrans>`，并明确声音连续跨越切点；不要把整句台词复制到两个 Shot。
