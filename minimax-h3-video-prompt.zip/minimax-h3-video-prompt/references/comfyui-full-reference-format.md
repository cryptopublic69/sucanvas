# ComfyUI Full-Reference 格式：R2VA

此格式用于 MiniMax H3 Reference to Video 节点，以及接入 `ref_image_N` 的非关键帧图片参考、图片/视频/音频混合参考、动作模仿和视频编辑任务。

## 固定六段

最终提示词严格按以下顺序输出。字段名不得翻译、改名、增删或调序：

```text
subject_definitions:
<Subject 1> ...
<Picture 1> ...
<Video 1> ...
<Audio 1> ...

summary:
[task type] - [concise English task summary]

retention_analysis:
<Subject 1> (appears in [Shot 1], ...): fully_preserved - ...
<Picture 1> (...): attribute_transfer - ...
<Video 1> (...): partially_preserved - ...
<Audio 1> (...): reference - ...

detailed_description:
[English style and global constraint sentences.]
[Shot 1] ...
[Shot 2] At 00:SS.mmm, ...

overall_soundscape:
[English ambience, sound effects, nonverbal voices, spatial mix and dynamics. Do not repeat dialogue.]

non_diegetic_music:
[English audience-only music description or N/A]
```

## 1. 官方标签与编号

- `ref_image_N` → `<Picture N>`
- `ref_video_N` → `<Video N>`
- `ref_video_audio_N` → 与同编号 `<Video N>` 配对的视频伴音；它会占用一个全局 `<Audio j>` 编号，并在对应 `<Video N>` 之前呈现
- `ref_audio_N` → 独立参考音频；其 `<Audio j>` 编号接在所有视频伴音之后，不保证与输入后缀 `N` 相同
- 需要单独跟踪的可见人物、物体或环境 → `<Subject N>`

标签一经定义，在六个字段中保持同一含义。若 `<Picture N>` / `<Video N>` 只用于说明某个 `<Subject N>` 的来源、后续不单独分析，可在该 Subject 的定义里引用，不必机械另起一行。

ComfyUI 的参考输入顺序为：图片，然后是视频（每段视频的配对伴音紧邻该视频），最后是独立音频。视频伴音与独立音频都进入 `<Audio j>` 序列，因此先根据节点实际组装顺序核对音频编号，不能把 `ref_video_audio_N` 和 `ref_audio_N` 当作两套各自从 1 开始的 `<Audio N>` 标签。

## 2. `subject_definitions`

每个需跟踪内容单独定义其含义、来源、参考职责和关键特征。人物需写清可见身份、脸型五官、发型、年龄感、服装和当前状态；场景需写空间结构与陈设；视频需说明是动作/镜头参考还是被编辑源。

说话角色按首次实际发声顺序绑定稳定 `(S1)`、`(S2)`。音频定义绑定到目标说话人时复用同一 `(Sx)`，不能因为音频本身再分配新说话人编号。

仅音色参考的安全定义：

```text
<Audio 1> is the voice-timbre reference for <Subject 1> (S1). Only the vocal timbre, texture, speaking quality, and delivery character are referenced; the original signal, wording, phonemes, breaths, pauses, timing, and background sounds are not copied.
```

## 3. `summary`

用一句英文写任务类型和目标。根据任务使用合适类型：

- `keyframe completion`
- `reference generation`
- `video editing`
- `video continuation`
- `audio reuse`
- `audio reference`

不要在 `summary` 写对白原文或展开镜头时间轴。

## 4. `retention_analysis`

一项参考一行，写明出现在哪些 Shot、使用何种关系以及具体保留/迁移内容。

视觉关系标记：

- `fully_preserved`
- `partially_preserved`
- `attribute_transfer`
- `weak_reference`

音频关系标记：

- `fully_copy`
- `partially_copy`
- `reference`
- `weak_reference`

只有用户明确要求复用原始可听信号或某段原音频时才用 `fully_copy` / `partially_copy`。只复用音色时必须用 `reference`：

```text
<Audio 1> (voice reference for <Subject 1> (S1) in [Shot 1] and [Shot 2]): reference - only the vocal timbre, texture, speaking quality, and delivery character are referenced. The original signal, wording, phonemes, breaths, pauses, timing, and background sounds are not copied.
```

这条是防止“使用音色参考后，视频开头先念随机含糊文字”的关键约束。不得把音频参考写成“fully preserved audio”“reuse the audio”或“continue the reference speech”。

## 5. `detailed_description`

Full-Reference 的主描述通常约 350–500 个英文词。先用一至两句英文建立风格和全局画面约束，再进入时间轴。

- `[Shot 1]` 无时间戳。
- 后续切镜使用 `[Shot N] At 00:SS.mmm, ...`。
- 每镜头包含构图/景别、主体位置与外观、动作、环境、光线、相机运动、对白、同步声音和转场。
- 同一 `<Subject N>` 与 `(Sx)` 全片稳定。
- 每句对白只在所属 Shot 出现一次。
- 跨切对白/歌词用 `<scenetrans>`；视频末尾被截断的发声用 `<cutoff>`。

标准对白：

```text
<Subject 1> (S1) says in a natural, lightly smiling tone, <d>[Chinese] 准确台词。</d>
```

`<d>` 内只能放语言标签和实际发声文字。人物名、动作、语气、音色来源和元注释放在标签外。

## 6. 声音字段

- `overall_soundscape`：环境声、动作声、非语言人声、空间混响、强弱变化与同步关系。
- `non_diegetic_music`：角色听不到、只有观众听到的配乐；无配乐写 `N/A`。
- 对白原文不得在这两个字段中重复。
- 参考音频只提供音色时，这两个字段不得引用其原台词、开场含糊声、原呼吸、原停顿、原时序或背景底噪。

## 7. 默认零文字第一句

若用户没有明确要求可见文字，把下句作为 `detailed_description:` 的第一句，位于 `[Shot 1]` 之前：

```text
The entire video contains no visible text of any kind, including subtitles, captions, titles, logos, watermarks, brand marks, signs, interface text, symbols, icons, stickers, or text-like graphics. No subtitles are rendered at any opacity; subtitle visibility is zero.
```

不得在 `subject_definitions` 之前添加旧式中文“最高优先级”区块，因为这会破坏官方六段结构。

## 8. 视频编辑模板要点

- `<Video N>` 定义为 source video for the target video edit。
- `summary` 使用 `video editing`。
- `retention_analysis` 写清原视频的保留项和允许修改项。
- `detailed_description` 写替换/新增对象如何继承原动作、接触、遮挡、透视、光影、反射、环境与声音。
- 未指定编辑的内容保持不变。
